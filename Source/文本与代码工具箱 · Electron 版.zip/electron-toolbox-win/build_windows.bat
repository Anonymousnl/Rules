@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install the current LTS version from https://nodejs.org/ and retry.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo npm was not found. Reopen the terminal after installing Node.js.
  pause
  exit /b 1
)
echo Installing Electron and local code engines. Internet is required for the first build.
call npm install
if errorlevel 1 (
  echo Dependency installation failed. Check your network and npm output.
  pause
  exit /b 1
)
echo Building Windows x64 installer and portable version...
echo Recommended for faster startup: install the NSIS version and launch from the desktop shortcut.
call npm run dist
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Build complete. Find both EXE files in the dist folder.
pause
