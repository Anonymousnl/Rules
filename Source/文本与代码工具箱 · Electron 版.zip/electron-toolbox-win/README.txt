文本与代码工具箱 - Electron Windows 打包项目（启动优化版）

优化内容：
- 使用 Electron 内置 Chromium，在独立桌面窗口运行，不调用 Chrome / Edge。
- CodeMirror 样式、编辑器与格式化/压缩引擎均随应用本地打包，不再从 CDN 下载。
- js-beautify、Terser、HTML Minifier 在首次点击对应操作时才加载，减少启动时的脚本解析和等待。
- CodeMirror 只渲染可视区域，避免大段代码在启动时全部渲染。
- 同时生成安装版和便携版。推荐安装版：安装后从桌面快捷方式启动，不必每次运行单文件便携包的自解压流程。

在 Windows 上生成 EXE：
1. 安装 Node.js LTS：https://nodejs.org/
2. 将本 ZIP 解压到可写文件夹。
3. 双击 build_windows.bat，等待依赖下载和构建完成。
4. 在 dist 文件夹中：
   - “文本与代码工具箱-安装程序-1.0.0-win-x64.exe”：推荐，安装后启动更快。
   - “文本与代码工具箱-便携版-1.0.0-win-x64.exe”：无需安装，但单文件便携包启动时可能需要自解压。

首次构建需要联网下载 npm 依赖和 Electron。构建完成后，四个工具的代码引擎均随应用本地打包，日常使用不再需要 CDN 网络请求。
