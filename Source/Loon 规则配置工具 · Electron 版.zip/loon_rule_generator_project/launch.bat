@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js LTS to run the Electron development app.
  echo To create a standalone installer, run build_windows.bat on Windows.
  pause
  exit /b 1
)
if not exist node_modules\electron\dist\electron.exe (
  echo Installing Electron dependencies for the first time...
  call npm install
  if errorlevel 1 goto failed
)
call npm start
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Failed to launch. Check Node.js, npm, and the console output.
pause
exit /b 1
