const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'ui', 'index.html'), 'utf8');
const renderer = fs.readFileSync(path.join(root, 'ui', 'renderer.js'), 'utf8');

for (const untranslated of [
  'RULE PIPELINE',
  '5 SOURCES',
  'Category=POLICY',
  '>READY</span>'
]) {
  assert.equal(html.includes(untranslated), false, `Found untranslated UI text: ${untranslated}`);
}
assert.ok(html.includes('GitHub 规则 · Loon 语法 · 智能分类'));
assert.ok(html.includes('Loon 规则配置工具'), 'App branding must use the Chinese product name');
assert.ok(html.includes('v0.5.18'), 'UI version label must match the current release');
const sourcePanelStart = html.indexOf('<div class="panel source-panel">');
const activityPanelStart = html.indexOf('<div class="panel activity-panel">');
const resultCardStart = html.indexOf('<div class="result-card" id="result-card">');
const outputPathStart = html.indexOf('<div class="output-path-group">');
assert.ok(sourcePanelStart >= 0 && activityPanelStart > sourcePanelStart, 'Source panel must remain left of the activity panel');
assert.ok(resultCardStart > outputPathStart && resultCardStart < activityPanelStart, 'Recent export card must be placed at the bottom of the left panel');
assert.ok(!html.slice(activityPanelStart).includes('id="result-card"'), 'Recent export card must not remain in the right panel');
const css = fs.readFileSync(path.join(root, 'ui', 'styles.css'), 'utf8');
assert.match(css, /\.source-panel \{ display: flex; flex-direction: column; min-height: 690px; \}/, 'Left panel must stretch to the same minimum height');
assert.match(css, /\.log-view \{ flex: 1 1 auto; height: auto; min-height: 230px;/, 'Log view must flex to fill the right panel above its bottom edge');

assert.equal(html.includes('Loon Rule Generator'), false, 'Old English product name must be removed from the UI');
assert.equal(html.includes('目标格式：Loon'), false, 'Requested footer label must be removed');
assert.equal(html.includes('固定 4 个在线来源 · domainset → non_ip → ip'), false, 'Requested footer pipeline text must be removed');
assert.equal(html.includes('规则文件与分类名称均使用英文'), false, 'Requested footer language note must be removed');
assert.equal(html.includes('仅使用上述 4 个仓库'), false, 'Requested source limitation note must be removed');
assert.ok(html.includes('规则流程'));
assert.ok(html.includes('3 个来源'));
assert.equal(html.includes('Loon0x00/LoonExampleConfig'), false, 'Removed repository must not appear in the UI');
assert.equal(renderer.includes('Loon0x00/LoonExampleConfig'), false, 'Removed repository must not remain in the renderer allowlist');
assert.equal(html.includes('SukkaW/Surge</code>'), false, 'Removed repository must not appear in the UI');
assert.equal(renderer.includes("'SukkaW/Surge'"), false, 'Removed repository must not remain in the renderer allowlist');
assert.equal(html.includes('GitHub 访问令牌'), false, 'GitHub token UI must be removed for pre-download mode');
assert.equal(html.includes('github-token'), false, 'GitHub token input must be removed');
assert.equal(renderer.includes('github-token'), false, 'Renderer must not depend on a token input');
assert.equal(html.includes('分类策略映射'), false, 'Hard-coded category policy mapping must not be shown in the UI');
assert.equal(html.includes('按分类覆盖源策略'), false, 'Policy override toggle must not be shown in the UI');
assert.equal(html.includes('REJECT-DROP'), false, 'Policy values must not be displayed in the UI');
for (const policyGroupName of ['AI专用策略', '国家时延优选', '兜底后备策略']) {
  assert.equal(html.includes(policyGroupName), false, `Policy group ${policyGroupName} must not be displayed in the UI`);
}
assert.equal(renderer.includes('policyMap'), false, 'Renderer must not expose or submit policy mapping settings');
assert.equal(renderer.includes('forcePolicy'), false, 'Renderer must not expose or submit policy override settings');
assert.ok(html.includes('id="prefetch-summary"'), 'Startup pre-download summary must be visible');
assert.ok(html.includes('data-repo-status="SukkaLab/ruleset.skk.moe"'), 'Each repository must have a visible pre-download status');
assert.ok(html.includes('重新预下载'), 'The user must be able to refresh the pre-download cache');
assert.ok(renderer.includes('function handlePrefetchEvent'), 'Renderer must process pre-download status events');

const start = renderer.indexOf('function localizeProgressMessage');
const end = renderer.indexOf('function resetStats');
assert.ok(start >= 0 && end > start, 'Localization helper functions must exist');
const helperSource = renderer.slice(start, end);
const sandbox = {};
vm.runInNewContext(`${helperSource}\nthis.localization = { localizeProgressMessage, localizeLogMessage, localizeErrorMessage };`, sandbox);
const { localizeProgressMessage, localizeLogMessage, localizeErrorMessage } = sandbox.localization;

assert.equal(
  localizeProgressMessage('Preparing to crawl 3 fixed repositories'),
  '准备抓取 3 个固定仓库'
);
assert.equal(
  localizeProgressMessage('blackmatrix7/ios_rule_script: downloading 122/813 - rule/Loon/Beats/Beats.list (25,341 bytes)'),
  '正在下载规则文件：blackmatrix7/ios_rule_script（122/813）· rule/Loon/Beats/Beats.list（25,341 字节）'
);
assert.equal(
  localizeLogMessage('[PARSE] blackmatrix7/ios_rule_script/rule/Loon/Example.list'),
  '[解析] blackmatrix7/ios_rule_script/rule/Loon/Example.list'
);
assert.equal(
  localizeLogMessage('[DONE] Rules=123, conflicts=2, unconverted=4'),
  '[完成] 规则：123 条；策略冲突：2 条；未转换：4 条'
);
assert.equal(
  localizeErrorMessage('HTTP Error 404: Not Found'),
  '请求的资源不存在（HTTP 404）：未找到'
);

console.log('UI localization tests passed.');

const mainSource = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');
const engineSource = fs.readFileSync(path.join(root, 'loon_rule_generator.py'), 'utf8');
assert.equal(mainSource.includes('policyMap'), false, 'Electron main process must not accept editable policy maps');
assert.equal(mainSource.includes('forcePolicy'), false, 'Electron main process must not accept a policy override toggle');
assert.match(engineSource, /policy_map = dict\(DEFAULT_POLICY_MAP\)/, 'Generation must use the hard-coded policy map');
assert.match(engineSource, /force_policy = True/, 'Generation must always apply the hard-coded category policy');
console.log('Hard-coded policy mapping tests passed.');
