import io
import json
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import loon_rule_generator as app


class FakeDownloader:
    def __init__(self, mapping=None):
        self.mapping = mapping or {}

    def fetch(self, url, use_cache=False):
        if url not in self.mapping:
            raise RuntimeError("missing fixture: " + url)
        return self.mapping[url]


class RuleParserTests(unittest.TestCase):
    def make_processor(self, mapping=None, force=True):
        return app.RuleProcessor(FakeDownloader(mapping), app.DEFAULT_POLICY_MAP, force_policy=force)

    def test_converts_surge_domain_rule(self):
        p = self.make_processor()
        p.parse_document("DOMAIN-SUFFIX,example.com,Proxy", "https://raw.githubusercontent.com/test/rules/AI.list", app.CAT_AI)
        self.assertEqual(len(p.rules), 1)
        self.assertEqual(p.rules[0].render(), "DOMAIN-SUFFIX,example.com,AI专用策略")

    def test_ip_no_resolve_order(self):
        p = self.make_processor()
        p.parse_document("IP-CIDR,192.0.2.0/24,no-resolve", "ip.list", app.CAT_AI)
        self.assertEqual(p.rules[0].render(), "IP-CIDR,192.0.2.0/24,AI专用策略,no-resolve")
        self.assertEqual(p.rules[0].family, "ip")

    def test_rule_set_render_omits_policy_but_preserves_options(self):
        p = self.make_processor()
        p.parse_document("IP-CIDR,192.0.2.0/24,no-resolve", "ip.list", app.CAT_AI)
        self.assertEqual(p.rules[0].render(), "IP-CIDR,192.0.2.0/24,AI专用策略,no-resolve")
        self.assertEqual(p.rules[0].render_rule_set(), "IP-CIDR,192.0.2.0/24,no-resolve")

    def test_bare_domain_is_domainset(self):
        p = self.make_processor()
        p.parse_document("example.com\nfoo.example", "domainset.txt", app.CAT_AI)
        self.assertEqual(len(p.rules), 2)
        self.assertTrue(all(r.family == "domainset" for r in p.rules))
        self.assertEqual(p.rules[0].render(), "DOMAIN-SUFFIX,example.com,AI专用策略")

    def test_adguard_exception_uses_allow_category(self):
        p = self.make_processor()
        p.parse_document("@@||example.com^\n||ads.example^", "adguard.txt", app.CAT_ADS)
        self.assertEqual(p.rules[0].category, app.CAT_ALLOW)
        self.assertEqual(p.rules[0].policy, "DIRECT")
        self.assertEqual(p.rules[1].policy, "REJECT")

    def test_domain_set_expansion(self):
        url = "https://rules.example/domainset.txt"
        p = self.make_processor({url: "example.com\nfoo.com\n"})
        p.parse_document(f"DOMAIN-SET,{url},PROXY", "https://github.com/test/repo/blob/main/AI.conf", app.CAT_AI)
        self.assertEqual(len(p.rules), 2)
        self.assertTrue(all(r.family == "domainset" for r in p.rules))

    def test_rule_set_expansion_inherits_policy(self):
        url = "https://rules.example/non_ip.list"
        p = self.make_processor({url: "DOMAIN-SUFFIX,example.com\nIP-CIDR,192.0.2.0/24,no-resolve\n"}, force=False)
        p.parse_document(f"RULE-SET,{url},DIRECT", "rules.list", app.CAT_AI)
        self.assertEqual(len(p.rules), 2)
        self.assertTrue(all(r.policy == "DIRECT" for r in p.rules))

    def test_preserves_source_policy_when_not_forced(self):
        p = self.make_processor(force=False)
        p.parse_document("DOMAIN-SUFFIX,example.com,DIRECT", "rules.list", app.CAT_AI)
        self.assertEqual(p.rules[0].policy, "DIRECT")

    def test_sukka_placeholder_policy_falls_back_to_category(self):
        p = self.make_processor(force=False)
        p.parse_document("DOMAIN-SUFFIX,example.com,[Replace with your policy]", "ai.conf", app.CAT_AI)
        self.assertEqual(p.rules[0].policy, "AI专用策略")

    def test_logical_rule_splits_only_top_level_commas(self):
        fields = app.split_rule_fields("AND,((DOMAIN-SUFFIX,example.com),(DEST-PORT,443)),DIRECT")
        self.assertEqual(fields, ["AND", "((DOMAIN-SUFFIX,example.com),(DEST-PORT,443))", "DIRECT"])

    def test_final_is_not_emitted(self):
        p = self.make_processor()
        p.parse_document("FINAL,DIRECT\nMATCH,PROXY", "rules.list", app.CAT_MISC)
        self.assertEqual(p.rules, [])
        self.assertEqual(len(p.unconverted), 2)

    def test_duplicate_and_policy_conflict(self):
        p = self.make_processor()
        p.parse_document("DOMAIN-SUFFIX,example.com", "ai.list", app.CAT_AI)
        p.parse_document("DOMAIN-SUFFIX,example.com", "direct.list", app.CAT_DIRECT)
        rules, duplicates, conflicts = app.sort_and_deduplicate(p.rules)
        self.assertEqual(len(rules), 1)
        self.assertEqual(duplicates, 1)
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(rules[0].category, app.CAT_AI)

    def test_candidate_filter(self):
        self.assertGreaterEqual(app.candidate_score("Rule/Surge/AI.list"), 3)
        self.assertLess(app.candidate_score("docs/README.txt"), 0)

    def test_candidate_filter_supports_hosts_and_filter_lists(self):
        self.assertGreaterEqual(app.candidate_score("hosts"), 3)
        self.assertGreaterEqual(app.candidate_score("easylist/easylist.txt"), 3)
        self.assertGreaterEqual(app.candidate_score("Filters/filter.txt"), 3)

    def test_default_repository_pool_is_exactly_the_three_requested_sources(self):
        self.assertEqual(app.DEFAULT_REPOSITORIES, [
            "SukkaLab/ruleset.skk.moe",
            "blackmatrix7/ios_rule_script",
            "Loyalsoldier/clash-rules",
        ])
        self.assertNotIn("Loon0x00/LoonExampleConfig", app.DEFAULT_REPOSITORIES)

    def test_loyalsoldier_clash_rules_is_pinned_to_release_branch(self):
        class CountingDownloader:
            def __init__(self):
                self.urls = []

            def fetch(self, url, use_cache=False):
                self.urls.append(url)
                return "DOMAIN-SUFFIX,example.com\n"

        class ReleaseBranchCrawler(app.GitHubCrawler):
            def __init__(self, downloader):
                super().__init__(downloader)
                self.api_urls = []

            def _api_json(self, url):
                self.api_urls.append(url)
                if "/git/trees/" in url:
                    return {"truncated": False, "tree": [
                        {"type": "blob", "path": "rules/AI.list", "size": 20},
                    ]}
                return {"default_branch": "master"}

        downloader = CountingDownloader()
        crawler = ReleaseBranchCrawler(downloader)
        files = list(crawler.collect_repo_files("Loyalsoldier/clash-rules"))
        tree_urls = [url for url in crawler.api_urls if "/git/trees/" in url]
        self.assertTrue(tree_urls)
        self.assertIn("/git/trees/release?recursive=1", tree_urls[0])
        self.assertEqual(len(files), 1)
        self.assertIn("/clash-rules/release/rules/AI.list", files[0][0])

    def test_clash_rules_cache_is_separated_by_release_branch(self):
        with tempfile.TemporaryDirectory() as tmp:
            cache_dir = app._repository_cache_dir(tmp, "Loyalsoldier/clash-rules")
            self.assertIn("release", cache_dir.name)
            old_default_branch_dir = Path(tmp) / "Loyalsoldier_clash-rules"
            self.assertNotEqual(cache_dir, old_default_branch_dir)
            cache_dir.mkdir(parents=True)
            (cache_dir / "manifest.json").write_text(json.dumps({
                "complete": True,
                "repository": "Loyalsoldier/clash-rules",
                "branch": "master",
                "files": [{"cache_file": "rules.txt", "path": "rules/AI.list", "url": "https://example.com/rules.txt"}],
            }), encoding="utf-8")
            self.assertIsNone(app.load_repository_cache(tmp, "Loyalsoldier/clash-rules"))

    def test_repo_crawler_has_no_file_count_or_size_cap(self):
        class CountingDownloader:
            def __init__(self):
                self.urls = []

            def fetch(self, url, use_cache=False):
                self.urls.append(url)
                return "DOMAIN-SUFFIX,example.com\n"

        class FakeTreeCrawler(app.GitHubCrawler):
            def _api_json(self, url):
                if "/git/trees/" in url:
                    return {"truncated": False, "tree": [
                        {"type": "blob", "path": f"rules/rule_{i:03d}.list", "size": 5 * 1024 * 1024 if i == 0 else 20}
                        for i in range(305)
                    ]}
                return {"default_branch": "main"}

        downloader = CountingDownloader()
        crawler = FakeTreeCrawler(downloader)
        files = list(crawler.collect_repo_files("test/repo"))
        self.assertEqual(len(files), 305)
        self.assertEqual(len(downloader.urls), 305)
        self.assertTrue(any(path == "rules/rule_000.list" for _, path, _ in files))

    def test_sukkalab_repository_only_crawls_list_and_clash_directories(self):
        class CountingDownloader:
            def __init__(self):
                self.urls = []

            def fetch(self, url, use_cache=False):
                self.urls.append(url)
                return "DOMAIN-SUFFIX,example.com\n"

        class FakeTreeCrawler(app.GitHubCrawler):
            def _api_json(self, url):
                if "/git/trees/" in url:
                    return {"truncated": False, "tree": [
                        {"type": "blob", "path": "List/AI.list", "size": 20},
                        {"type": "blob", "path": "List/subfolder/Streaming.list", "size": 20},
                        {"type": "blob", "path": "Clash/AI.list", "size": 20},
                        {"type": "blob", "path": "Clash/subfolder/General.list", "size": 20},
                        {"type": "blob", "path": "Surge/AI.list", "size": 20},
                        {"type": "blob", "path": "Rule/Streaming.list", "size": 20},
                        {"type": "blob", "path": "List_extra/AI.list", "size": 20},
                        {"type": "blob", "path": "Clashish/AI.list", "size": 20},
                    ]}
                return {"default_branch": "master"}

        downloader = CountingDownloader()
        crawler = FakeTreeCrawler(downloader)
        files = list(crawler.collect_repo_files("SukkaLab/ruleset.skk.moe"))
        paths = [path for _, path, _ in files]
        self.assertCountEqual(paths, [
            "List/AI.list",
            "List/subfolder/Streaming.list",
            "Clash/AI.list",
            "Clash/subfolder/General.list",
        ])
        self.assertEqual(len(downloader.urls), 4)
        self.assertTrue(all(path.casefold().startswith(("list/", "clash/")) for path in paths))

    def test_blackmatrix_repository_only_crawls_rule_loon_directory(self):
        class CountingDownloader:
            def __init__(self):
                self.urls = []

            def fetch(self, url, use_cache=False):
                self.urls.append(url)
                return "DOMAIN-SUFFIX,example.com\n"

        class FakeTreeCrawler(app.GitHubCrawler):
            def _api_json(self, url):
                if "/git/trees/" in url:
                    return {"truncated": False, "tree": [
                        {"type": "blob", "path": "rule/Loon/AI.list", "size": 20},
                        {"type": "blob", "path": "rule/Loon/Streaming.list", "size": 20},
                        {"type": "blob", "path": "rule/Loon/subfolder/General.list", "size": 20},
                        {"type": "blob", "path": "rule/Surge/AI.list", "size": 20},
                        {"type": "blob", "path": "rule/Clash/AI.list", "size": 20},
                        {"type": "blob", "path": "README.list", "size": 20},
                    ]}
                return {"default_branch": "master"}

        downloader = CountingDownloader()
        crawler = FakeTreeCrawler(downloader)
        files = list(crawler.collect_repo_files("blackmatrix7/ios_rule_script"))
        paths = [path for _, path, _ in files]
        self.assertEqual(paths, [
            "rule/Loon/AI.list",
            "rule/Loon/Streaming.list",
            "rule/Loon/subfolder/General.list",
        ])
        self.assertEqual(len(downloader.urls), 3)
        self.assertTrue(all(path.casefold().startswith("rule/loon/") for path in paths))

    def test_repository_extraction_and_download_retry_until_success(self):
        class FlakyDownloader:
            def __init__(self):
                self.attempts = {}

            def fetch(self, url, use_cache=False):
                self.attempts[url] = self.attempts.get(url, 0) + 1
                attempt = self.attempts[url]
                if attempt == 1:
                    raise RuntimeError("temporary network failure")
                if url == "https://api.github.com/repos/test/repo":
                    return json.dumps({"default_branch": "main"})
                if "/git/trees/main?recursive=1" in url:
                    return json.dumps({"truncated": False, "tree": [
                        {"type": "blob", "path": "rules/AI.list", "size": 20}
                    ]})
                if url.startswith("https://raw.githubusercontent.com/test/repo/main/"):
                    if attempt == 2:
                        return "   "  # Empty responses are retried as well.
                    return "DOMAIN-SUFFIX,example.ai\n"
                raise AssertionError("Unexpected URL: " + url)

        downloader = FlakyDownloader()
        logs = []
        progress = []
        crawler = app.GitHubCrawler(downloader, logger=logs.append, progress=progress.append)
        with patch.object(app.time, "sleep", return_value=None):
            files = list(crawler.collect_repo_files("test/repo"))
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0][1], "rules/AI.list")
        self.assertIn("DOMAIN-SUFFIX,example.ai", files[0][2])
        self.assertEqual(downloader.attempts["https://api.github.com/repos/test/repo"], 2)
        tree_url = "https://api.github.com/repos/test/repo/git/trees/main?recursive=1"
        self.assertEqual(downloader.attempts[tree_url], 2)
        raw_url = files[0][0]
        self.assertEqual(downloader.attempts[raw_url], 3)
        self.assertGreaterEqual(sum("[RETRY]" in line for line in logs), 3)
        self.assertTrue(any("正在重试" in line for line in progress))

    def test_parser_exception_retries_without_duplicate_partial_rules(self):
        processor = self.make_processor()
        original_parse = processor.parse_document
        calls = {"count": 0}

        def flaky_parse(content, source, **kwargs):
            calls["count"] += 1
            original_parse(content, source, **kwargs)
            if calls["count"] == 1:
                raise RuntimeError("temporary parser failure")

        logs = []
        with patch.object(processor, "parse_document", side_effect=flaky_parse):
            with patch.object(app.time, "sleep", return_value=None):
                app.parse_document_until_success(
                    processor,
                    "DOMAIN-SUFFIX,example.ai",
                    "fixture.list",
                    app.CAT_AI,
                    logger=logs.append,
                )
        self.assertEqual(calls["count"], 2)
        self.assertEqual(len(processor.rules), 1)
        self.assertEqual(processor.sequence, 1)
        self.assertTrue(any("[RETRY] parse rule file" in line for line in logs))

    def test_retry_backoff_is_capped(self):
        self.assertEqual(app.retry_delay_seconds(RuntimeError("network"), 1), 2.0)
        self.assertEqual(app.retry_delay_seconds(RuntimeError("network"), 2), 4.0)
        self.assertEqual(app.retry_delay_seconds(RuntimeError("network"), 20), 60.0)

    def test_downloader_uses_anonymous_github_access_without_token_header(self):
        seen = {}

        class FakeResponse:
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, tb):
                return False
            def read(self, *args):
                return b"{}"

        def fake_urlopen(request, timeout=None):
            seen["request"] = request
            seen["timeout"] = timeout
            return FakeResponse()

        with patch.object(app, "urlopen", side_effect=fake_urlopen):
            app.Downloader().fetch("https://api.github.com/repos/example/repo", use_cache=False)
        self.assertEqual(seen["request"].get_header("Authorization"), None)
        self.assertEqual(seen["timeout"], 25)

    def test_downloader_reads_files_larger_than_old_default_cap(self):
        payload = b"x" * (2 * 1024 * 1024 + 1)

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def read(self, *args):
                return payload if not args else payload[:args[0]]

        with patch.object(app, "urlopen", return_value=FakeResponse()):
            content = app.Downloader().fetch("https://example.com/large.list", use_cache=False)
        self.assertEqual(len(content), len(payload))

    def test_policy_defaults_support_reject_drop_and_named_proxy_groups(self):
        self.assertEqual(app.DEFAULT_POLICY_MAP[app.CAT_ADS], "REJECT")
        self.assertEqual(app.DEFAULT_POLICY_MAP[app.CAT_TRACKING], "REJECT-DROP")
        self.assertEqual(app.DEFAULT_POLICY_MAP[app.CAT_AI], "AI专用策略")
        self.assertEqual(app.DEFAULT_POLICY_MAP[app.CAT_GLOBAL], "兜底后备策略")
        self.assertEqual(app.DEFAULT_POLICY_MAP[app.CAT_MISC], "兜底后备策略")
        self.assertEqual(app.DEFAULT_POLICY_MAP[app.CAT_STREAM], "国家时延优选")
        self.assertEqual(app.normalize_policy("reject-drop"), "REJECT-DROP")
        self.assertEqual(app.classify_category("Privacy-Tracking.list"), app.CAT_TRACKING)
        self.assertEqual(app.classify_category("AdGuard/Advertising.list"), app.CAT_ADS)

    def test_english_category_labels_and_classifier(self):
        labels = [*app.CATEGORY_ORDER, *app.FAMILY_LABELS.values()]
        self.assertTrue(all(label.isascii() for label in labels))
        self.assertEqual(app.classify_category("Advertising.list"), app.CAT_ADS)
        self.assertEqual(app.classify_category("AI.list"), app.CAT_AI)

    def test_apple_intelligence_is_classified_as_ai_before_apple(self):
        self.assertEqual(app.classify_category("Apple/AppleIntelligence.list"), app.CAT_AI)
        self.assertEqual(app.classify_category("Apple/Apple Intelligence.list"), app.CAT_AI)
        self.assertEqual(app.classify_category("Apple/PrivateCloudCompute.list"), app.CAT_AI)
        self.assertEqual(app.classify_category("Apple/Apple.list"), app.CAT_APPLE)

    def test_apple_intelligence_rules_inside_apple_source_move_to_ai(self):
        p = self.make_processor()
        p.parse_document(
            "DOMAIN-SUFFIX,appleintelligence.apple.com\n"
            "DOMAIN-SUFFIX,privatecloudcompute.apple.com\n"
            "DOMAIN-SUFFIX,icloud.com\n",
            "Apple.list",
            app.CAT_APPLE,
        )
        self.assertEqual([rule.category for rule in p.rules], [app.CAT_AI, app.CAT_AI, app.CAT_APPLE])
        self.assertEqual([rule.policy for rule in p.rules], ["AI专用策略", "AI专用策略", "国家时延优选"])

    def test_export_uses_english_category_filenames_and_comments(self):
        rules = [
            app.Rule("DOMAIN-SUFFIX", "example.ai", "PROXY", (), app.CAT_AI, "domainset", "fixture", 1, "example.ai"),
            app.Rule("DOMAIN-SUFFIX", "stream.example", "PROXY", (), app.CAT_STREAM, "domainset", "fixture", 2, "stream.example"),
            app.Rule("DOMAIN-SUFFIX", "ads.example", "REJECT", (), app.CAT_ADS, "domainset", "fixture", 3, "ads.example"),
        ]
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir)
            export_result = app.export_results(output, rules, 0, [], [], [], app.DEFAULT_POLICY_MAP, True)
            category_dir = output / "by_category"
            self.assertTrue((category_dir / "AI.lsr").exists())
            self.assertTrue((category_dir / "Streaming.lsr").exists())
            self.assertTrue((category_dir / "Advertising.lsr").exists())
            self.assertTrue((output / "all_rules.lsr").exists())
            self.assertTrue((output / "by_family" / "domainset.lsr").exists())
            self.assertFalse((category_dir / "AI.list").exists())
            all_rules = (output / "all_rules.lsr").read_text(encoding="utf-8")
            self.assertIn("# --- AI ---", all_rules)
            self.assertIn("# ===== DOMAINSET - Domain Set =====", all_rules)
            self.assertIn("DOMAIN-SUFFIX,example.ai", all_rules)
            self.assertNotIn("DOMAIN-SUFFIX,example.ai,PROXY", all_rules)
            ai_rules = (category_dir / "AI.lsr").read_text(encoding="utf-8")
            self.assertIn("DOMAIN-SUFFIX,example.ai", ai_rules)
            self.assertNotIn("AI专用策略", ai_rules)
            family_rules = (output / "by_family" / "domainset.lsr").read_text(encoding="utf-8")
            self.assertNotIn(",PROXY", family_rules)
            index = (output / "category_index.md").read_text(encoding="utf-8")
            self.assertIn("by_category/Advertising.lsr", index)
            self.assertIn("rule_order.txt", index)
            self.assertNotIn("广告", index)
            order_path = output / "rule_order.txt"
            self.assertTrue(order_path.exists())
            order = order_path.read_text(encoding="utf-8")
            self.assertIn("Scope: generated rule-set files in by_category/ only.", order)
            self.assertIn("[0001] by_category/Advertising.lsr | CATEGORY=Advertising | POLICY=REJECT", order)
            self.assertIn("[0002] by_category/AI.lsr | CATEGORY=AI | POLICY=AI专用策略", order)
            self.assertIn("[0003] by_category/Streaming.lsr | CATEGORY=Streaming | POLICY=国家时延优选", order)
            self.assertLess(order.index("by_category/Advertising.lsr"), order.index("by_category/AI.lsr"))
            self.assertLess(order.index("by_category/AI.lsr"), order.index("by_category/Streaming.lsr"))
            self.assertNotIn("DOMAIN-SUFFIX,", order)
            self.assertIn("POLICY=REJECT", order)
            self.assertIn("POLICY=AI专用策略", order)
            self.assertIn("POLICY=国家时延优选", order)
            custom_order = app.rule_order_text([app.CAT_ADS], "test-time", {app.CAT_ADS: "REJECT-DROP"})
            self.assertIn("CATEGORY=Advertising | POLICY=REJECT-DROP", custom_order)
            manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["rule_order_file"], "rule_order.txt")
            self.assertEqual(manifest["rule_order_scope"], "by_category .lsr rule-set files only; individual rules inside each file are not listed or reordered by rule_order.txt")
            self.assertEqual(manifest["rule_order_category_files"], ["by_category/Advertising.lsr", "by_category/AI.lsr", "by_category/Streaming.lsr"])
            with zipfile.ZipFile(export_result["zip_path"]) as archive:
                self.assertIn("rule_order.txt", archive.namelist())


if __name__ == "__main__":
    unittest.main(verbosity=2)


class ElectronEngineBridgeTests(unittest.TestCase):
    def test_run_generation_uses_only_fixed_online_repository_allowlist(self):
        seen_repositories = []

        class StubDownloader:
            def __init__(self, *args, **kwargs):
                pass

            def fetch(self, url, use_cache=False):
                raise AssertionError("Direct URLs must not be fetched")

        class StubCrawler:
            def __init__(self, downloader, logger=None, progress=None):
                self.logger = logger
                self.progress = progress

            def collect_repo_files(self, repo):
                seen_repositories.append(repo)
                if repo == app.DEFAULT_REPOSITORIES[0]:
                    yield ("https://raw.githubusercontent.com/SukkaLab/ruleset.skk.moe/master/List/AI.list", "AI.list", "DOMAIN-SUFFIX,example.com,PROXY\n")

        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(app, "Downloader", StubDownloader), \
             patch.object(app, "GitHubCrawler", StubCrawler):
            result = app.run_generation({
                "repositories": ["attacker/extra-repo"],
                "directUrls": ["https://rules.example/rules.list"],
                "query": "discover extra repos",
                "onlineDiscovery": True,
                "discoveryCount": 20,
                "maxRepositories": 50,
                "outputDir": tmp,
                "policyMap": {app.CAT_AI: "CUSTOM-POLICY"},
                "forcePolicy": False,
            })
            self.assertEqual(result["rule_count"], 1)
            self.assertEqual(seen_repositories, app.DEFAULT_REPOSITORIES)
            self.assertTrue((Path(tmp) / "all_rules.lsr").exists())
            generated = (Path(tmp) / "all_rules.lsr").read_text(encoding="utf-8")
            self.assertIn("DOMAIN-SUFFIX,example.com", generated)
            self.assertNotIn("DOMAIN-SUFFIX,example.com,AI专用策略", generated)
            self.assertNotIn("DOMAIN-SUFFIX,example.com,CUSTOM-POLICY", generated)
            self.assertTrue(Path(result["zip_path"]).exists())

    def test_prefetch_caches_all_fixed_repositories_and_reports_status(self):
        class StubDownloader:
            def __init__(self, *args, **kwargs):
                pass

        class StubCrawler:
            def __init__(self, downloader, logger=None, progress=None):
                self.progress = progress

            def collect_repo_files(self, repo):
                if repo == "SukkaLab/ruleset.skk.moe":
                    path = "List/AI.list"
                elif repo == "blackmatrix7/ios_rule_script":
                    path = "rule/Loon/AI.list"
                else:
                    path = "rules/AI.list"
                if self.progress:
                    self.progress(f"{repo}: downloading 1/1 - {path} (34 bytes)")
                yield (f"https://raw.example/{repo}/{path}", path, "DOMAIN-SUFFIX,example.com,PROXY\n")

        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(app, "Downloader", StubDownloader), \
             patch.object(app, "GitHubCrawler", StubCrawler):
            events = []
            result = app.run_prefetch({"cacheDir": tmp}, repository_event=events.append)
            self.assertEqual(result["completed"], 3)
            self.assertEqual(result["total"], 3)
            self.assertEqual([x["repository"] for x in result["repositories"]], app.DEFAULT_REPOSITORIES)
            self.assertTrue(all(x["status"] == "completed" for x in result["repositories"]))
            self.assertEqual(sum(1 for event in events if event["status"] == "completed"), 3)
            for repo in app.DEFAULT_REPOSITORIES:
                manifest = app.load_repository_cache(tmp, repo)
                self.assertIsNotNone(manifest)
                self.assertEqual(len(manifest["files"]), 1)
                cached = list(app.iter_cached_repository_files(tmp, repo))
                self.assertEqual(cached[0][2], "DOMAIN-SUFFIX,example.com,PROXY\n")

    def test_failed_refresh_keeps_previous_complete_cache(self):
        class StubDownloader:
            def __init__(self, *args, **kwargs):
                pass

        class GoodCrawler:
            def __init__(self, downloader, logger=None, progress=None):
                self.progress = progress

            def collect_repo_files(self, repo):
                path = "List/AI.list" if repo == "SukkaLab/ruleset.skk.moe" else (
                    "rule/Loon/AI.list" if repo == "blackmatrix7/ios_rule_script" else "rules/AI.list"
                )
                yield (f"https://raw.example/{repo}/{path}", path, "DOMAIN-SUFFIX,old.example,PROXY\n")

        class BrokenRefreshCrawler:
            def __init__(self, downloader, logger=None, progress=None):
                self.progress = progress

            def collect_repo_files(self, repo):
                path = "List/AI.list" if repo == "SukkaLab/ruleset.skk.moe" else (
                    "rule/Loon/AI.list" if repo == "blackmatrix7/ios_rule_script" else "rules/AI.list"
                )
                yield (f"https://raw.example/{repo}/{path}", path, "DOMAIN-SUFFIX,new.example,PROXY\n")
                raise OSError("simulated cache write interruption")

        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(app, "Downloader", StubDownloader), \
             patch.object(app, "GitHubCrawler", GoodCrawler):
            app.run_prefetch({"cacheDir": tmp})
            with patch.object(app, "GitHubCrawler", BrokenRefreshCrawler):
                result = app.run_prefetch({"cacheDir": tmp})
            self.assertEqual(result["completed"], 0)
            for repo in app.DEFAULT_REPOSITORIES:
                cached = list(app.iter_cached_repository_files(tmp, repo))
                self.assertIn("old.example", cached[0][2])
                self.assertNotIn("new.example", cached[0][2])

    def test_generation_reuses_complete_prefetch_cache_without_live_downloads(self):
        class StubDownloader:
            def __init__(self, *args, **kwargs):
                pass

        class StubCrawler:
            def __init__(self, downloader, logger=None, progress=None):
                self.progress = progress

            def collect_repo_files(self, repo):
                path = "List/AI.list" if repo == "SukkaLab/ruleset.skk.moe" else (
                    "rule/Loon/AI.list" if repo == "blackmatrix7/ios_rule_script" else "rules/AI.list"
                )
                yield (f"https://raw.example/{repo}/{path}", path, "DOMAIN-SUFFIX,example.com,PROXY\n")

        class NoLiveCrawler:
            def __init__(self, downloader, logger=None, progress=None):
                pass

            def collect_repo_files(self, repo):
                raise AssertionError(f"Live download should not be used for cached repo: {repo}")

        with tempfile.TemporaryDirectory() as cache_tmp, tempfile.TemporaryDirectory() as output_tmp, \
             patch.object(app, "Downloader", StubDownloader), \
             patch.object(app, "GitHubCrawler", StubCrawler):
            app.run_prefetch({"cacheDir": cache_tmp})
            with patch.object(app, "GitHubCrawler", NoLiveCrawler):
                result = app.run_generation({
                    "cacheDir": cache_tmp,
                    "outputDir": output_tmp,
                    "policyMap": app.DEFAULT_POLICY_MAP,
                    "forcePolicy": False,
                })
            self.assertEqual(result["rule_count"], 1)
            self.assertTrue((Path(output_tmp) / "all_rules.lsr").exists())
            manifest = json.loads((Path(output_tmp) / "manifest.json").read_text(encoding="utf-8"))
            repo_sources = [item for item in manifest["source_inventory"] if item.get("repository") in app.DEFAULT_REPOSITORIES and item.get("status") == "ok"]
            self.assertEqual(len(repo_sources), 3)
            self.assertTrue(all(item.get("fetch_mode") == "predownload_cache" for item in repo_sources))

    def test_json_worker_routes_prefetch_action(self):
        payload = {"cacheDir": "cache"}
        with patch.object(app.sys, "stdin", io.StringIO(json.dumps({"action": "prefetch", **payload}))), \
             patch.object(app, "run_prefetch", return_value={"completed": 3, "total": 3}), \
             patch("builtins.print") as mocked_print:
            status = app.run_json_worker()
        self.assertEqual(status, 0)
        emitted = json.loads(mocked_print.call_args.args[0])
        self.assertEqual(emitted["type"], "prefetch-done")
        self.assertEqual(emitted["result"]["completed"], 3)

    def test_json_worker_emits_machine_readable_done_event(self):
        with patch.object(app.sys, "stdin", io.StringIO("{}")), \
             patch.object(app, "run_generation", return_value={"rule_count": 3}), \
             patch("builtins.print") as mocked_print:
            status = app.run_json_worker()
        self.assertEqual(status, 0)
        emitted = json.loads(mocked_print.call_args.args[0])
        self.assertEqual(emitted["type"], "done")
        self.assertEqual(emitted["result"]["rule_count"], 3)
