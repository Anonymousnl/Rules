const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const APP_VERSION = '0.5.18';
const DEFAULT_REPOSITORIES = [
  'SukkaLab/ruleset.skk.moe',
  'blackmatrix7/ios_rule_script',
  'Loyalsoldier/clash-rules'
];
let mainWindow = null;
let activeChild = null;
let activeRunToken = 0;
let prefetchChild = null;
let prefetchRunToken = 0;

function defaultSettings() {
  return {
    outputDir: path.join(app.getPath('documents'), 'LoonRuleGeneratorOutput')
  };
}

function settingsPath() {
  return path.join(app.getPath('userData'), 'settings.json');
}

function getSettings() {
  const defaults = defaultSettings();
  try {
    const saved = JSON.parse(fs.readFileSync(settingsPath(), 'utf8'));
    return { outputDir: String(saved.outputDir || defaults.outputDir) };
  } catch {
    return defaults;
  }
}

function persistSettings(input) {
  const defaults = defaultSettings();
  const safe = { outputDir: String(input.outputDir || defaults.outputDir) };
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
  fs.writeFileSync(settingsPath(), JSON.stringify(safe, null, 2), 'utf8');
  return { saved: true };
}

function sendRunEvent(payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('generation:event', payload);
  }
}

function sendPrefetchEvent(payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('prefetch:event', payload);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 940,
    minWidth: 1080,
    minHeight: 720,
    backgroundColor: '#0b1020',
    title: 'Loon 规则配置工具',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.loadFile(path.join(__dirname, '..', 'ui', 'index.html'));
  mainWindow.on('closed', () => { mainWindow = null; });
}

function backendCandidates() {
  if (app.isPackaged) {
    return [{
      command: path.join(process.resourcesPath, 'engine', 'LoonRuleEngine.exe'),
      args: [],
      cwd: app.getPath('userData')
    }];
  }

  const projectRoot = path.join(__dirname, '..');
  const entry = path.join(projectRoot, 'engine', 'engine_entry.py');
  const cwd = projectRoot;
  if (process.env.LRG_PYTHON) {
    return [{ command: process.env.LRG_PYTHON, args: [entry], cwd }];
  }
  if (process.platform === 'win32') {
    return [
      { command: 'py', args: ['-3', entry], cwd },
      { command: 'python', args: [entry], cwd }
    ];
  }
  return [
    { command: 'python3', args: [entry], cwd },
    { command: 'python', args: [entry], cwd }
  ];
}

function startGeneration(config) {
  if (prefetchChild) {
    sendRunEvent({ type: 'error', message: '仓库预下载仍在运行；请等待完成或先停止预下载。' });
    return;
  }
  if (activeChild) {
    sendRunEvent({ type: 'error', message: 'A generation task is already running.' });
    return;
  }

  const runToken = ++activeRunToken;
  const safeConfig = {
    repositories: [...DEFAULT_REPOSITORIES],
    directUrls: [],
    query: '',
    onlineDiscovery: false,
    discoveryCount: 0,
    maxRepositories: DEFAULT_REPOSITORIES.length,
    outputDir: String(config.outputDir || defaultSettings().outputDir),
    cacheDir: path.join(app.getPath('userData'), 'repository-cache')
  };
  persistSettings(safeConfig);
  sendRunEvent({ type: 'status', message: '正在启动规则处理引擎…' });

  const candidates = backendCandidates();
  const attempt = (index) => {
    if (runToken !== activeRunToken) return;
    if (index >= candidates.length) {
      activeChild = null;
      sendRunEvent({ type: 'error', message: '未能启动规则引擎。开发模式请安装 Python 3.10+；已安装 Python 时请确认 py 或 python 命令可用。' });
      return;
    }

    const candidate = candidates[index];
    let spawned = false;
    let stdoutBuffer = '';
    let stderrBuffer = '';
    let terminalPayload = null;
    let child;
    try {
      child = spawn(candidate.command, candidate.args, {
        cwd: candidate.cwd,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
      });
    } catch (error) {
      attempt(index + 1);
      return;
    }
    activeChild = child;

    const parseLine = (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      try {
        const payload = JSON.parse(trimmed);
        if (payload.type === 'done' || payload.type === 'error') {
          terminalPayload = payload;
        } else {
          sendRunEvent(payload);
        }
      } catch {
        sendRunEvent({ type: 'log', message: trimmed });
      }
    };

    child.once('spawn', () => {
      spawned = true;
      sendRunEvent({ type: 'status', message: '规则引擎已启动，正在访问 GitHub…' });
      child.stdin.end(JSON.stringify(safeConfig));
    });

    child.stdout.on('data', (chunk) => {
      stdoutBuffer += chunk.toString('utf8');
      const lines = stdoutBuffer.split(/\r?\n/);
      stdoutBuffer = lines.pop() || '';
      for (const line of lines) parseLine(line);
    });

    child.stderr.on('data', (chunk) => {
      stderrBuffer += chunk.toString('utf8');
      const lines = stderrBuffer.split(/\r?\n/);
      stderrBuffer = lines.pop() || '';
      for (const line of lines) {
        if (line.trim()) sendRunEvent({ type: 'log', message: `[ENGINE] ${line.trim()}` });
      }
    });

    child.once('error', (error) => {
      if (runToken !== activeRunToken) return;
      if (!spawned && index + 1 < candidates.length) {
        activeChild = null;
        attempt(index + 1);
      } else if (!spawned) {
        activeChild = null;
        sendRunEvent({ type: 'error', message: `无法启动规则引擎：${error.message}` });
      } else {
        sendRunEvent({ type: 'log', message: `[ENGINE] ${error.message}` });
      }
    });

    child.once('close', (code, signal) => {
      if (runToken !== activeRunToken || activeChild !== child) return;
      if (stdoutBuffer.trim()) parseLine(stdoutBuffer);
      if (stderrBuffer.trim()) sendRunEvent({ type: 'log', message: `[ENGINE] ${stderrBuffer.trim()}` });
      activeChild = null;
      if (terminalPayload) {
        sendRunEvent(terminalPayload);
      } else {
        sendRunEvent({
          type: 'error',
          message: `规则引擎提前退出（exit=${code}, signal=${signal || 'none'}）。请查看日志或重新运行。`
        });
      }
    });
  };

  attempt(0);
}


function startPrefetch() {
  if (prefetchChild) return;
  const runToken = ++prefetchRunToken;
  const safeConfig = {
    action: 'prefetch',
    repositories: [...DEFAULT_REPOSITORIES],
    cacheDir: path.join(app.getPath('userData'), 'repository-cache')
  };
  sendPrefetchEvent({ type: 'status', message: '正在准备预下载固定的 3 个 GitHub 仓库…' });
  const candidates = backendCandidates();

  const attempt = (index) => {
    if (runToken !== prefetchRunToken) return;
    if (index >= candidates.length) {
      prefetchChild = null;
      sendPrefetchEvent({ type: 'error', message: '无法启动预下载引擎。开发模式请安装 Python 3.10+，或检查引擎是否已构建。' });
      return;
    }
    const candidate = candidates[index];
    let spawned = false;
    let stdoutBuffer = '';
    let stderrBuffer = '';
    let terminalPayload = null;
    let child;
    try {
      child = spawn(candidate.command, candidate.args, {
        cwd: candidate.cwd,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
      });
    } catch {
      attempt(index + 1);
      return;
    }
    prefetchChild = child;

    const parseLine = (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      try {
        const payload = JSON.parse(trimmed);
        if (payload.type === 'prefetch-done' || payload.type === 'error') terminalPayload = payload;
        else sendPrefetchEvent(payload);
      } catch {
        sendPrefetchEvent({ type: 'log', message: trimmed });
      }
    };

    child.once('spawn', () => {
      spawned = true;
      sendPrefetchEvent({ type: 'status', message: '已启动预下载引擎，正在逐个获取仓库及规则文件…' });
      child.stdin.end(JSON.stringify(safeConfig));
    });
    child.stdout.on('data', (chunk) => {
      stdoutBuffer += chunk.toString('utf8');
      const lines = stdoutBuffer.split(/\r?\n/);
      stdoutBuffer = lines.pop() || '';
      for (const line of lines) parseLine(line);
    });
    child.stderr.on('data', (chunk) => {
      stderrBuffer += chunk.toString('utf8');
      const lines = stderrBuffer.split(/\r?\n/);
      stderrBuffer = lines.pop() || '';
      for (const line of lines) if (line.trim()) sendPrefetchEvent({ type: 'log', message: `[ENGINE] ${line.trim()}` });
    });
    child.once('error', (error) => {
      if (runToken !== prefetchRunToken) return;
      if (!spawned && index + 1 < candidates.length) {
        prefetchChild = null;
        attempt(index + 1);
      } else if (!spawned) {
        prefetchChild = null;
        sendPrefetchEvent({ type: 'error', message: `无法启动预下载引擎：${error.message}` });
      } else {
        sendPrefetchEvent({ type: 'log', message: `[ENGINE] ${error.message}` });
      }
    });
    child.once('close', (code, signal) => {
      if (runToken !== prefetchRunToken || prefetchChild !== child) return;
      if (stdoutBuffer.trim()) parseLine(stdoutBuffer);
      if (stderrBuffer.trim()) sendPrefetchEvent({ type: 'log', message: `[ENGINE] ${stderrBuffer.trim()}` });
      prefetchChild = null;
      if (terminalPayload) sendPrefetchEvent(terminalPayload);
      else sendPrefetchEvent({ type: 'error', message: `预下载引擎提前退出（exit=${code}, signal=${signal || 'none'}）。` });
    });
  };
  attempt(0);
}

function stopPrefetch() {
  if (!prefetchChild) return Promise.resolve(false);
  const child = prefetchChild;
  if (child.prefetchStopPromise) return child.prefetchStopPromise;
  prefetchRunToken += 1;
  child.prefetchStopPromise = new Promise((resolve) => {
    const finish = () => {
      if (prefetchChild === child) prefetchChild = null;
      sendPrefetchEvent({ type: 'stopped', message: '已停止预下载。每个仓库上一次完整缓存仍可使用；没有可用缓存的仓库会在生成时在线获取。' });
      resolve(true);
    };
    child.once('close', finish);
    sendPrefetchEvent({ type: 'status', message: '正在停止预下载并保留上一次完整缓存…' });
    child.kill();
  });
  return child.prefetchStopPromise;
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  if (activeChild) activeChild.kill();
  if (prefetchChild) prefetchChild.kill();
});

ipcMain.handle('app:get-initial-data', () => ({
  version: APP_VERSION,
  settings: getSettings(),
  defaults: defaultSettings()
}));

ipcMain.handle('settings:save', (_event, settings) => persistSettings(settings || {}));

ipcMain.handle('dialog:select-output-dir', async (_event, currentPath) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '选择规则导出目录',
    defaultPath: currentPath || defaultSettings().outputDir,
    properties: ['openDirectory', 'createDirectory']
  });
  return result.canceled || !result.filePaths.length ? null : result.filePaths[0];
});

ipcMain.handle('shell:open-output-dir', async (_event, outputDir) => {
  const target = String(outputDir || defaultSettings().outputDir);
  fs.mkdirSync(target, { recursive: true });
  const error = await shell.openPath(target);
  if (error) throw new Error(error);
  return true;
});

ipcMain.on('generation:start', (_event, config) => startGeneration(config || {}));
ipcMain.on('prefetch:start', () => startPrefetch());
ipcMain.handle('prefetch:stop', async () => await stopPrefetch());
ipcMain.on('generation:stop', () => {
  if (!activeChild) return;
  activeRunToken += 1;
  const child = activeChild;
  activeChild = null;
  child.kill();
  sendRunEvent({ type: 'stopped', message: '已停止任务。当前输出目录可能包含本次运行的部分结果。' });
});
