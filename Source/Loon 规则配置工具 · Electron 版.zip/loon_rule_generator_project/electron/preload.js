const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('loonAPI', {
  getInitialData: () => ipcRenderer.invoke('app:get-initial-data'),
  saveSettings: (settings) => ipcRenderer.invoke('settings:save', settings),
  selectOutputDir: (currentPath) => ipcRenderer.invoke('dialog:select-output-dir', currentPath),
  openOutputDir: (outputDir) => ipcRenderer.invoke('shell:open-output-dir', outputDir),
  startGeneration: (config) => ipcRenderer.send('generation:start', config),
  stopGeneration: () => ipcRenderer.send('generation:stop'),
  startPrefetch: () => ipcRenderer.send('prefetch:start'),
  stopPrefetch: () => ipcRenderer.invoke('prefetch:stop'),
  onRunEvent: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('generation:event', listener);
    return () => ipcRenderer.removeListener('generation:event', listener);
  },
  onPrefetchEvent: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('prefetch:event', listener);
    return () => ipcRenderer.removeListener('prefetch:event', listener);
  }
});
