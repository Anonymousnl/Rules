"""Console entry point for the packaged Electron rule engine."""
from pathlib import Path
import sys

# Keep the tested rule engine at the project root as the single source of truth.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from loon_rule_generator import run_json_worker  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run_json_worker())
