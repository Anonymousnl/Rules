@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install the current Node.js LTS release first.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo npm was not found. Reinstall Node.js with npm included.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto failed
call npm run dist:win
if errorlevel 1 goto failed
echo.
echo Build complete. Check the release folder for the Windows installer.
pause
exit /b 0
:failed
echo.
echo Build failed. Review the error messages above.
pause
exit /b 1
