# Loon 规则配置工具 v0.5.18

Windows Electron desktop tool for pre-downloading rule files from a fixed GitHub allowlist, converting them to Loon syntax, classifying and de-duplicating rules, checking policy conflicts, and exporting `.lsr` rule sets.

## Features

- Automatically pre-downloads three fixed GitHub repositories when the Electron UI opens and shows per-repository waiting, downloading, retrying, completed, failed, or paused status.
- Uses local completed cache snapshots first during generation; if no complete cache exists, it falls back to online fetching.
- GitHub access-token input and token authentication have been removed. Requests use anonymous GitHub access; GitHub's unauthenticated API limits still apply.
- `SukkaLab/ruleset.skk.moe`: only `List/` and `Clash/` directories and their descendants.
- `blackmatrix7/ios_rule_script`: only `rule/Loon/` and its descendants.
- `Loyalsoldier/clash-rules`: pinned to the `release` branch, with a branch-specific cache.
- No per-repository file-count cap and no per-file size cap. Files are processed one by one to reduce memory pressure.
- Retries repository metadata/tree extraction, candidate discovery, individual downloads, empty responses, and parser exceptions until success. Stop the task manually if a source is permanently unavailable.
- Converts common Surge, Clash, QX, Hosts, domain list, and IP list formats into supported Loon rule syntax.
- English category labels and `.lsr` filenames; internal rule order is preserved. Explicit Apple Intelligence / Private Cloud Compute rule sets and matching rules are routed from `Apple` into `AI` before the general Apple classifier; ordinary iCloud, App Store, Apple Music, and other Apple service rules stay in `Apple`. Individual `.lsr` entries omit routing policy fields; assign each category rule-set policy through the `POLICY=` value in `rule_order.txt` / the corresponding Loon rule-set reference.
- `rule_order.txt` lists only generated `by_category/*.lsr` files with their `CATEGORY=` and `POLICY=` values. It does not list or reorder individual rules inside a rule set.
- Places the “最近一次导出” card at the bottom of the left panel; the right-side log window flexes to fill the available height so both panels share the same bottom edge.
- Exports duplicate/conflict reports, unconverted entries, source inventory, category index, manifest, and a ZIP archive.

## Fixed policy mapping

Category-to-policy routing is hard-coded in the rule engine and is not exposed as an editable setting in either desktop interface. Source-file policies are overridden by the fixed category mapping during generation.

```text
Allowlist=DIRECT
Advertising=REJECT
Tracking=REJECT-DROP
LAN=DIRECT
AI=AI专用策略
Apple=国家时延优选
Microsoft=国家时延优选
Telegram=国家时延优选
Streaming=国家时延优选
Social=国家时延优选
Search=国家时延优选
Games=国家时延优选
China=DIRECT
CDN=国家时延优选
Direct=DIRECT
Global-Proxy=兜底后备策略
General=兜底后备策略
```

The policy-group names `AI专用策略`, `国家时延优选`, and `兜底后备策略` must match the names in your Loon configuration. If a group name changes, update `DEFAULT_POLICY_MAP` in `loon_rule_generator.py` and rebuild the Windows package.

## Run on Windows

1. Install Node.js LTS and Python 3.10+.
2. Extract this project ZIP.
3. Double-click `launch.bat` to start the Electron development app.
4. Wait for repository pre-download statuses to update, then click **开始生成**.

To build a Windows installer, run `build_windows.bat` on Windows. The installer build uses Electron Builder and packages the Python rule engine.

## Output files

- `all_rules.lsr` — combined rules grouped by family/category while preserving collection order within each group.
- `by_category/*.lsr` — category rule sets without per-rule policy fields; apply policy at the rule-set reference level.
- `by_family/*.lsr` — `domainset`, `non_ip`, and `ip` family split.
- `rule_order.txt` — ordered list of category rule-set files with `CATEGORY=` and `POLICY=`.
- `category_index.md`, `manifest.json`, `rule_sources.csv`, `conflicts.csv`, `unconverted.txt`, and a timestamped ZIP.

These files are rule sets, not a complete Loon profile. They do not create policy groups or a final fallback rule. Review conflicts and unconverted entries before importing, and ensure every custom policy name exists in your Loon configuration.

## Development checks

```powershell
python -m unittest discover -s tests -v
node --check electron/main.js
node --check electron/preload.js
node --check ui/renderer.js
node tests/test_ui_localization.js
```
