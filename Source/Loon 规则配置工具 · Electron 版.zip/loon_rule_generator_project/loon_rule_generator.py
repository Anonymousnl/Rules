#!/usr/bin/env python3
"""Local Windows Loon rule collector, converter, classifier and de-duplicator.

Standard-library only. The Electron app pre-downloads fixed repository rule files on startup and reuses the local cache during generation.
"""
from __future__ import annotations

import csv
import hashlib
import ipaddress
import json
import os
import queue
import re
import shutil
import sys
import threading
import time
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen

APP_NAME = "Loon 规则配置工具"
VERSION = "0.5.18"
ALLOWED_EXTENSIONS = {".list", ".lsr", ".conf", ".txt", ".rule", ".rules", ".yaml", ".yml"}

# Loon rule types documented at https://nsloon.app/docs/category/\u89c4\u5219/
RULE_TYPE_ALIASES = {
    "HOST": "DOMAIN",
    "HOST-SUFFIX": "DOMAIN-SUFFIX",
    "HOST-KEYWORD": "DOMAIN-KEYWORD",
    "HOST-WILDCARD": "DOMAIN-WILDCARD",
    "IP6-CIDR": "IP-CIDR6",
    "IP-CIDR6": "IP-CIDR6",
    "IP-CIDR": "IP-CIDR",
    "DST-PORT": "DEST-PORT",
    "DEST-PORT": "DEST-PORT",
    "SOURCE-PORT": "SRC-PORT",
    "SRC-PORT": "SRC-PORT",
    "MATCH": "FINAL",
}
SUPPORTED_RULE_TYPES = {
    "DOMAIN", "DOMAIN-SUFFIX", "DOMAIN-KEYWORD", "DOMAIN-WILDCARD",
    "IP-CIDR", "IP-CIDR6", "IP-ASN", "GEOIP", "USER-AGENT", "URL-REGEX",
    "PROCESS-NAME", "DEST-PORT", "SRC-PORT", "PROTOCOL", "AND", "OR", "NOT",
    "FINAL",
}
IP_RULE_TYPES = {"IP-CIDR", "IP-CIDR6", "IP-ASN", "GEOIP"}
DOMAIN_RULE_TYPES = {"DOMAIN", "DOMAIN-SUFFIX", "DOMAIN-KEYWORD", "DOMAIN-WILDCARD", "USER-AGENT", "URL-REGEX"}
OPTION_WORDS = {
    "no-resolve", "extended-matching", "pre-matching", "force-remote-dns",
    "no-resolve=true", "no-resolve=false",
}

# Output category labels are English so generated filenames, comments, CSVs,
# the category index, and the manifest are easy to use across locales.
CAT_ADS = "Advertising"
CAT_TRACKING = "Tracking"
CAT_ALLOW = "Allowlist"
CAT_LAN = "LAN"
CAT_AI = "AI"
CAT_APPLE = "Apple"
CAT_MS = "Microsoft"
CAT_TELEGRAM = "Telegram"
CAT_STREAM = "Streaming"
CAT_SOCIAL = "Social"
CAT_SEARCH = "Search"
CAT_GAMES = "Games"
CAT_CN = "China"
CAT_CDN = "CDN"
CAT_DIRECT = "Direct"
CAT_GLOBAL = "Global-Proxy"
CAT_MISC = "General"
CATEGORY_ORDER = [
    CAT_ALLOW, CAT_ADS, CAT_TRACKING, CAT_LAN, CAT_AI, CAT_APPLE, CAT_MS, CAT_TELEGRAM,
    CAT_STREAM, CAT_SOCIAL, CAT_SEARCH, CAT_GAMES, CAT_CN, CAT_CDN,
    CAT_DIRECT, CAT_GLOBAL, CAT_MISC,
]
FAMILY_ORDER = ["domainset", "non_ip", "ip"]
FAMILY_LABELS = {
    "domainset": "DOMAINSET - Domain Set",
    "non_ip": "NON_IP - Non-IP Rules",
    "ip": "IP - IP Rules",
}
DEFAULT_POLICY_MAP = {
    CAT_ALLOW: "DIRECT",
    CAT_ADS: "REJECT",
    CAT_TRACKING: "REJECT-DROP",
    CAT_LAN: "DIRECT",
    CAT_AI: "AI专用策略",
    CAT_APPLE: "国家时延优选",
    CAT_MS: "国家时延优选",
    CAT_TELEGRAM: "国家时延优选",
    CAT_STREAM: "国家时延优选",
    CAT_SOCIAL: "国家时延优选",
    CAT_SEARCH: "国家时延优选",
    CAT_GAMES: "国家时延优选",
    CAT_CN: "DIRECT",
    CAT_CDN: "国家时延优选",
    CAT_DIRECT: "DIRECT",
    CAT_GLOBAL: "兜底后备策略",
    CAT_MISC: "兜底后备策略",
}
# Repository-specific scopes keep repositories with multiple client formats
# from contributing rules for other clients. Paths are matched case-insensitively.
REPOSITORY_PATH_PREFIXES = {
    ("sukkalab", "ruleset.skk.moe"): ("List/", "Clash/"),
    ("blackmatrix7", "ios_rule_script"): ("rule/Loon/",),
}

DEFAULT_REPOSITORIES = [
    "SukkaLab/ruleset.skk.moe",
    "blackmatrix7/ios_rule_script",
    "Loyalsoldier/clash-rules",
]

# Pin repositories whose rule source must not follow the GitHub default branch.
REPOSITORY_BRANCHES = {
    ("loyalsoldier", "clash-rules"): "release",
}


RETRY_BASE_DELAY_SECONDS = 2
RETRY_MAX_DELAY_SECONDS = 60


def log_call(logger: Optional[Callable[[str], None]], message: str) -> None:
    if logger:
        logger(message)


def retry_delay_seconds(exc: Exception, attempt: int) -> float:
    """Use server-provided retry hints when available, otherwise capped backoff."""
    if isinstance(exc, HTTPError):
        headers = exc.headers or {}
        retry_after = headers.get("Retry-After") if headers else None
        if retry_after:
            try:
                return max(1.0, float(retry_after))
            except (TypeError, ValueError):
                pass
        remaining = headers.get("X-RateLimit-Remaining") if headers else None
        reset = headers.get("X-RateLimit-Reset") if headers else None
        if str(remaining) == "0" and reset:
            try:
                return max(1.0, float(reset) - time.time() + 1.0)
            except (TypeError, ValueError):
                pass
    exponent = min(max(attempt - 1, 0), 10)
    return float(min(RETRY_BASE_DELAY_SECONDS * (2 ** exponent), RETRY_MAX_DELAY_SECONDS))


def retry_until_success(operation, label: str, logger=None, progress=None, validator=None):
    """Retry an online extraction/parse operation without an attempt limit.

    The capped exponential delay avoids hammering GitHub. The task can still be
    stopped by terminating the local engine process from the Electron UI.
    """
    attempt = 0
    while True:
        try:
            result = operation()
            if validator is not None:
                validator(result)
            return result
        except Exception as exc:
            attempt += 1
            delay = retry_delay_seconds(exc, attempt)
            detail = str(exc).replace("\n", " ").strip() or exc.__class__.__name__
            log_call(logger, f"[RETRY] {label} failed on attempt {attempt}: {detail}. Retrying in {delay:g}s; no retry limit.")
            log_call(progress, f"正在重试：{label}（第 {attempt} 次失败，{delay:g} 秒后重试）")
            time.sleep(delay)


def normalize_policy(policy: str) -> str:
    raw = (policy or "").strip()
    low = raw.lower()
    if not raw or (raw.startswith("[") and raw.endswith("]")) or "replace with your policy" in low or "${" in raw:
        return ""
    aliases = {
        "direct": "DIRECT", "reject": "REJECT", "reject-drop": "REJECT-DROP",
        "reject-nodrop": "REJECT-NO-DROP", "reject-no-drop": "REJECT-NO-DROP",
        "proxy": "PROXY", "global": "PROXY", "match": "PROXY",
        "bypass": "DIRECT", "block": "REJECT",
    }
    return aliases.get(low, raw)


def is_apple_intelligence_text(value: str) -> bool:
    """Recognize explicit Apple Intelligence / Private Cloud Compute labels."""
    text = str(value or "").lower().replace("\\", "/")
    compact = re.sub(r"[^a-z0-9]+", "", text)
    return any(marker in compact for marker in (
        "appleintelligence",
        "privatecloudcompute",
    ))


def classify_rule_category(source: str, default_category: str, rule_value: str = "") -> str:
    """Apply narrow per-rule overrides before inheriting a source file category."""
    if is_apple_intelligence_text(source) or is_apple_intelligence_text(rule_value):
        return CAT_AI
    if default_category == CAT_MISC:
        return classify_category(source, rule_value=rule_value)
    return default_category


def classify_category(path_or_name: str, repo: str = "", rule_value: str = "") -> str:
    text = (str(path_or_name) + " " + repo + " " + rule_value).lower().replace("\\", "/")
    # Apple Intelligence is a specific AI subcategory and must be checked before Apple.
    if is_apple_intelligence_text(text):
        return CAT_AI
    # More specific categories are checked before generic words such as "global".
    if any(k in text for k in ("allowlist", "allow-list", "whitelist", "white_list", "exception", "@@||")):
        return CAT_ALLOW
    if any(k in text for k in ("tracking", "tracker", "telemetry", "fingerprint", "analytics", "privacy", "anti-track", "tracking-protection")):
        return CAT_TRACKING
    if any(k in text for k in ("reject", "adblock", "ad-block", "adguard", "advertising", "ads", "anti-ad", "malware", "phishing", "blacklist", "black-list", "blocklist")):
        return CAT_ADS
    if any(k in text for k in ("telegram", "t.me", "telegram.org")):
        return CAT_TELEGRAM
    if any(k in text for k in ("openai", "chatgpt", "claude", "gemini", "perplexity", "/ai", "ai.list", "ai.conf", "artificial-intelligence")):
        return CAT_AI
    if any(k in text for k in ("apple", "icloud", "app-store", "applemusic", "apple_music", "apple-tv")):
        return CAT_APPLE
    if any(k in text for k in ("microsoft", "onedrive", "office365", "office-365", "windowsupdate", "xboxlive")):
        return CAT_MS
    if any(k in text for k in ("stream", "netflix", "youtube", "spotify", "disney", "primevideo", "prime-video", "hulu", "twitch", "tiktok", "bilibili", "iqiyi", "bahamut", "hbo", "crunchyroll", "peacock", "viu", "dazn")):
        return CAT_STREAM
    if any(k in text for k in ("facebook", "instagram", "twitter", "x.com", "reddit", "discord", "whatsapp", "line.me", "snapchat", "social")):
        return CAT_SOCIAL
    if any(k in text for k in ("google", "bing", "duckduckgo", "search", "yandex", "baidu-search")):
        return CAT_SEARCH
    if any(k in text for k in ("steam", "epicgames", "playstation", "nintendo", "games", "game/", "xbox", "ea-games", "battle.net")):
        return CAT_GAMES
    if any(k in text for k in ("lan", "private", "localhost", "localnetwork", "local-network", "intranet", "rfc1918")):
        return CAT_LAN
    if any(k in text for k in ("download", "cdn", "object-storage", "objects", "speedtest", "software-update")):
        return CAT_CDN
    if any(k in text for k in ("domestic", "china", "chnroute", "china_ip", "cn.list", "cn.conf", "baidu", "tencent", "wechat", "weixin", "alipay", "taobao", "jd.com", "qq.com", "netease")):
        return CAT_CN
    if any(k in text for k in ("direct", "bypass", "whitelist-mode")):
        return CAT_DIRECT
    if any(k in text for k in ("global", "proxy", "foreign", "geolocation-!cn")):
        return CAT_GLOBAL
    return CAT_MISC


def category_priority(category: str) -> int:
    try:
        return CATEGORY_ORDER.index(category)
    except ValueError:
        return len(CATEGORY_ORDER)


def family_for_rule(rule_type: str, source_family_hint: Optional[str] = None) -> str:
    if rule_type in IP_RULE_TYPES:
        return "ip"
    if source_family_hint == "domainset" and rule_type in {"DOMAIN", "DOMAIN-SUFFIX"}:
        return "domainset"
    return "non_ip"


def split_rule_fields(line: str) -> list[str]:
    """Split commas only at top level; preserve commas inside logical-rule parentheses."""
    fields: list[str] = []
    current: list[str] = []
    depth = 0
    quote_char = ""
    escaped = False
    for ch in line:
        if escaped:
            current.append(ch)
            escaped = False
            continue
        if ch == "\\":
            current.append(ch)
            escaped = True
            continue
        if quote_char:
            current.append(ch)
            if ch == quote_char:
                quote_char = ""
            continue
        if ch in ('"', "'"):
            quote_char = ch
            current.append(ch)
            continue
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            fields.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    fields.append("".join(current).strip())
    return fields


def strip_inline_comment(line: str) -> str:
    quote_char = ""
    escaped = False
    for i, ch in enumerate(line):
        if escaped:
            escaped = False
            continue
        if ch == "\\":
            escaped = True
            continue
        if quote_char:
            if ch == quote_char:
                quote_char = ""
            continue
        if ch in ('"', "'"):
            quote_char = ch
            continue
        if ch == "#" and i > 0 and line[i - 1].isspace():
            return line[:i].rstrip()
    return line.strip()


def normalize_rule_value(value: str) -> str:
    value = value.strip().strip('"').strip("'")
    if value.lower().startswith("*."):
        return value[2:].lower()
    return value


def is_domain(value: str) -> bool:
    value = value.rstrip(".")
    if not value or len(value) > 253 or " " in value or "/" in value or ":" in value:
        return False
    if value.lower() == "localhost":
        return True
    labels = value.split(".")
    if len(labels) < 2:
        return False
    label_re = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$")
    return all(label_re.fullmatch(label) for label in labels)


def is_ip_or_network(value: str) -> tuple[Optional[str], Optional[str]]:
    try:
        if "/" in value:
            net = ipaddress.ip_network(value, strict=False)
            return ("IP-CIDR6" if net.version == 6 else "IP-CIDR", str(net))
        addr = ipaddress.ip_address(value)
        bits = 128 if addr.version == 6 else 32
        return ("IP-CIDR6" if addr.version == 6 else "IP-CIDR", f"{addr}/{bits}")
    except ValueError:
        return (None, None)


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return name or "rules"


@dataclass
class Rule:
    rule_type: str
    value: str
    policy: str
    options: tuple[str, ...]
    category: str
    family: str
    source: str
    source_line: int
    original: str
    sequence: int = 0

    def render(self) -> str:
        """Render a full rule with its routing policy for diagnostics and reports."""
        fields = [self.rule_type, self.value, self.policy]
        fields.extend(self.options)
        return ",".join(fields)

    def render_rule_set(self) -> str:
        """Render a rule-set entry without policy; routing is set on the rule-set reference."""
        fields = [self.rule_type, self.value]
        fields.extend(self.options)
        return ",".join(fields)

    def match_key(self) -> tuple:
        value = self.value.strip()
        if self.rule_type not in {"URL-REGEX", "USER-AGENT", "AND", "OR", "NOT"}:
            value = value.lower()
        return (self.rule_type.upper(), value, tuple(o.lower() for o in self.options))

    def exact_key(self) -> tuple:
        return self.match_key() + (self.policy.lower(),)


class Downloader:
    def __init__(self, logger=None):
        self.logger = logger
        # Cache only callers that explicitly opt in; large rule files are fetched
        # without caching so unlimited downloads do not retain every file in RAM.
        self.cache: dict[str, str] = {}

    def fetch(self, url: str, use_cache: bool = False) -> str:
        url = normalize_github_url(url.strip())
        if use_cache and url in self.cache:
            return self.cache[url]
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            raise ValueError("Only http/https URLs are supported")
        headers = {"User-Agent": f"Loon-Rule-Generator/{VERSION}", "Accept": "application/vnd.github+json, text/plain, */*"}
        request = Request(url, headers=headers)
        with urlopen(request, timeout=25) as response:
            data = response.read()
        text = data.decode("utf-8-sig", errors="replace")
        if use_cache:
            self.cache[url] = text
        return text


def normalize_github_url(url: str) -> str:
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    parts = [p for p in parsed.path.split("/") if p]
    if host == "github.com" and len(parts) >= 5 and parts[2] == "blob":
        owner, repo, _, branch = parts[:4]
        rest = "/".join(parts[4:])
        return f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{rest}"
    if host == "github.com" and len(parts) >= 5 and parts[2] == "raw":
        owner, repo, _, branch = parts[:4]
        rest = "/".join(parts[4:])
        return f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{rest}"
    return url


def parse_repo_spec(spec: str) -> tuple[str, str, Optional[str]]:
    raw = spec.strip().rstrip("/")
    branch = None
    if "@" in raw and not raw.startswith("http"):
        raw, branch = raw.rsplit("@", 1)
    if raw.startswith("http://") or raw.startswith("https://"):
        parsed = urlparse(raw)
        if parsed.hostname not in {"github.com", "www.github.com"}:
            raise ValueError("Not a github.com repository URL")
        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) < 2:
            raise ValueError("Repository URL must include owner/repo")
        owner, repo = parts[0], parts[1]
    else:
        parts = raw.split("/")
        if len(parts) != 2:
            raise ValueError("Use owner/repo or https://github.com/owner/repo")
        owner, repo = parts
    repo = repo.removesuffix(".git")
    if not owner or not repo:
        raise ValueError("Invalid repository spec")
    return owner, repo, branch


def candidate_score(path: str) -> int:
    lower = path.lower().replace("\\", "/")
    parts = lower.split("/")
    base = parts[-1]
    ext = Path(base).suffix
    # Some useful public lists (notably StevenBlack/hosts) have no extension.
    if ext not in ALLOWED_EXTENSIONS and not (not ext and base == "hosts"):
        return -100
    if base in {"readme.md", "license", "license.md", "package.json"}:
        return -100
    negative = ("/docs/", "/doc/", "/module", "/rewrite", "/script", "/test", "/mock/", "/assets/", "/images/", "/.github/", "/node_modules/")
    if any(x in "/" + lower for x in negative):
        return -100
    score = 0
    positive_parts = {
        "rule", "rules", "ruleset", "rule-set", "list", "surge", "loon", "clash",
        "domainset", "non_ip", "ip", "hosts", "rulesets", "adguard", "adblock",
        "easylist", "anti-ad", "privacy", "blocklist", "blocklists", "filter", "filters",
        "1hosts", "dns-blocklists", "hagezi",
    }
    if any(part in positive_parts for part in parts[:-1]):
        score += 5
    if any(k in lower for k in (
        "rule", "ruleset", "reject", "direct", "proxy", "apple", "google", "ai", "stream",
        "telegram", "china", "lan", "cdn", "domainset", "adguard", "adblock", "easylist",
        "anti-ad", "privacy", "malware", "phishing", "blocklist", "filter", "hosts", "1hosts",
        "hagezi",
    )):
        score += 2
    if ext in {".list", ".lsr", ".rule", ".rules"}:
        score += 2
    if ext == ".txt":
        score += 1
    if not ext and base == "hosts":
        score += 3
    if ext == ".conf":
        score += 1
    if ext in {".yaml", ".yml"}:
        score -= 1
    if "source/" in lower or "/source/" in lower:
        score += 1
    if any(k in lower for k in ("profile", "config", "template")):
        score -= 2
    return score if score >= 3 else -100


class GitHubCrawler:
    def __init__(self, downloader: Downloader, logger=None, progress=None):
        self.downloader = downloader
        self.logger = logger
        self.progress = progress

    def _api_json(self, url: str) -> dict:
        def load_json():
            payload = json.loads(self.downloader.fetch(url, use_cache=False))
            if not isinstance(payload, dict):
                raise ValueError("GitHub API response is not a JSON object")
            if "message" in payload and not any(key in payload for key in ("tree", "default_branch")):
                raise RuntimeError(f"GitHub API error: {payload.get('message')}")
            return payload

        return retry_until_success(
            load_json, f"GitHub API request {url}", self.logger, self.progress
        )

    def _all_tree_entries(self, owner: str, repo: str, branch: str, tree: dict) -> list[dict]:
        """Return all tree entries, walking non-recursive trees if GitHub truncates a large response."""
        if not tree.get("truncated"):
            return tree.get("tree", [])

        log_call(self.logger, f"[WARN] {owner}/{repo}: recursive GitHub tree response was truncated; walking directory trees individually.")
        api_root = f"https://api.github.com/repos/{owner}/{repo}/git/trees/"
        root = self._api_json(api_root + quote(branch, safe=""))
        entries: list[dict] = []
        stack: list[tuple[str, str]] = []
        for item in root.get("tree", []):
            path = item.get("path", "")
            if item.get("type") == "tree" and item.get("sha"):
                stack.append((item["sha"], path))
            elif item.get("type") == "blob":
                entries.append(dict(item, path=path))

        while stack:
            tree_sha, prefix = stack.pop()
            subtree = self._api_json(api_root + quote(tree_sha, safe=""))
            if subtree.get("truncated"):
                log_call(self.logger, f"[WARN] {owner}/{repo}: one directory tree is still truncated by GitHub; the API omitted entries from {prefix}.")
            for item in subtree.get("tree", []):
                relative = item.get("path", "")
                full_path = f"{prefix}/{relative}".strip("/") if prefix else relative
                if item.get("type") == "tree" and item.get("sha"):
                    stack.append((item["sha"], full_path))
                elif item.get("type") == "blob":
                    entries.append(dict(item, path=full_path))
        return entries

    def collect_repo_files(self, spec: str) -> Iterable[tuple[str, str, str]]:
        """Yield rule-like files; retry repository extraction and each download until successful."""
        owner, repo, explicit_branch = parse_repo_spec(spec)
        repo_api = f"https://api.github.com/repos/{owner}/{repo}"
        repo_key = (owner.casefold(), repo.casefold())
        allowed_prefixes = REPOSITORY_PATH_PREFIXES.get(repo_key, ())
        if allowed_prefixes:
            log_call(self.logger, f"[INFO] {owner}/{repo}: restricting crawl to {', '.join(allowed_prefixes)}")

        def discover_candidates():
            repo_info = self._api_json(repo_api)
            branch = explicit_branch or REPOSITORY_BRANCHES.get(repo_key) or repo_info.get("default_branch")
            if not branch:
                raise ValueError("Repository metadata did not provide a default branch")
            tree_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{quote(branch, safe='')}?recursive=1"
            tree = self._api_json(tree_url)
            if not isinstance(tree.get("tree"), list):
                raise ValueError("GitHub tree response did not contain a tree list")
            entries = self._all_tree_entries(owner, repo, branch, tree)
            candidates = []
            for item in entries:
                if item.get("type") != "blob":
                    continue
                path = item.get("path", "")
                normalized_path = path.replace("\\", "/").lstrip("/")
                if allowed_prefixes and not any(
                    normalized_path.casefold().startswith(prefix.casefold())
                    for prefix in allowed_prefixes
                ):
                    continue
                score = candidate_score(path)
                if score < 0:
                    continue
                candidates.append((score, path, int(item.get("size") or 0)))
            candidates.sort(key=lambda item: (-item[0], item[1].lower()))
            if not candidates:
                scope = f" within {', '.join(allowed_prefixes)}" if allowed_prefixes else ""
                raise RuntimeError(f"No rule files were discovered in {owner}/{repo}{scope}")
            return branch, candidates

        branch, candidates = retry_until_success(
            discover_candidates,
            f"extract repository {owner}/{repo}",
            self.logger,
            self.progress,
        )
        log_call(self.logger, f"[INFO] {owner}/{repo}@{branch}: found {len(candidates)} candidate rule files; no per-repository file-count or per-file size cap.")
        for index, (_, path, size) in enumerate(candidates, 1):
            raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{quote(branch, safe='/')}/{quote(path, safe='/')}"
            if self.progress:
                size_label = f" ({size:,} bytes)" if size else ""
                self.progress(f"{owner}/{repo}: downloading {index}/{len(candidates)} - {path}{size_label}")

            def fetch_rule_file():
                content = self.downloader.fetch(raw_url, use_cache=False)
                if not isinstance(content, str) or not content.strip():
                    raise ValueError("Downloaded rule file is empty; waiting for a valid response")
                return content

            content = retry_until_success(
                fetch_rule_file,
                f"download rule file {owner}/{repo}/{path}",
                self.logger,
                self.progress,
            )
            yield (raw_url, path, content)


class RuleProcessor:
    def __init__(self, downloader: Downloader, policy_map: dict[str, str], force_policy: bool = True, logger=None):
        self.downloader = downloader
        self.policy_map = dict(DEFAULT_POLICY_MAP)
        self.policy_map.update(policy_map)
        self.force_policy = force_policy
        self.logger = logger
        self.rules: list[Rule] = []
        self.unconverted: list[dict] = []
        self.sequence = 0
        self.expansion_seen: set[tuple] = set()
        self.max_expansion_depth = 3

    def policy_for(self, category: str, source_policy: Optional[str], inherited_policy: Optional[str]) -> str:
        default = self.policy_map.get(category, self.policy_map.get(CAT_MISC, "PROXY"))
        if self.force_policy:
            return normalize_policy(default)
        if source_policy:
            normalized_source = normalize_policy(source_policy)
            if normalized_source:
                return normalized_source
        if inherited_policy:
            normalized_inherited = normalize_policy(inherited_policy)
            if normalized_inherited:
                return normalized_inherited
        return normalize_policy(default)

    def _unconverted(self, source: str, line_number: int, line: str, reason: str) -> None:
        self.unconverted.append({"source": source, "line": line_number, "text": line, "reason": reason})

    def _add_rule(self, rule_type: str, value: str, category: str, source: str, line_number: int,
                  original: str, source_policy: Optional[str], inherited_policy: Optional[str],
                  options: Iterable[str] = (), family_hint: Optional[str] = None) -> None:
        if rule_type == "FINAL":
            self._unconverted(source, line_number, original, "Terminal FINAL/MATCH rules are omitted from rule-set files to avoid shadowing later rules.")
            return
        if rule_type not in SUPPORTED_RULE_TYPES:
            self._unconverted(source, line_number, original, f"Rule type not supported by this converter: {rule_type}")
            return
        policy = self.policy_for(category, source_policy, inherited_policy)
        option_list = tuple(o.strip() for o in options if o.strip())
        # The Loon syntax places the policy before options, e.g. IP-CIDR,1.2.3.0/24,DIRECT,no-resolve.
        self.sequence += 1
        family = family_for_rule(rule_type, family_hint)
        self.rules.append(Rule(rule_type, value.strip(), policy, option_list, category, family,
                               source, line_number, original.strip(), self.sequence))

    def _fetch_expansion(self, url: str, source: str, line_number: int, category: str,
                         inherited_policy: Optional[str], mode: str, depth: int, stack: tuple[str, ...]) -> None:
        if depth >= self.max_expansion_depth:
            self._unconverted(source, line_number, url, "Remote rule expansion depth limit reached.")
            return
        key = (url, category, inherited_policy or "", mode)
        if key in self.expansion_seen or url in stack:
            return
        self.expansion_seen.add(key)
        try:
            text = self.downloader.fetch(url, use_cache=False)
        except Exception as exc:
            self._unconverted(source, line_number, url, f"Could not fetch referenced rule set: {exc}")
            return
        remote_category = classify_category(url, rule_value="")
        if category == CAT_MISC and remote_category != CAT_MISC:
            category = remote_category
        self.parse_document(text, url, default_category=category, inherited_policy=inherited_policy,
                            depth=depth + 1, stack=stack + (url,), force_domainset=(mode == "domainset"))

    def parse_document(self, text: str, source: str, default_category: Optional[str] = None,
                       inherited_policy: Optional[str] = None, depth: int = 0,
                       stack: tuple[str, ...] = (), force_domainset: bool = False) -> None:
        source_category = classify_category(source)
        category = CAT_AI if is_apple_intelligence_text(source) else (default_category or source_category)
        if category == CAT_MISC:
            category = source_category
        for line_number, raw in enumerate(text.splitlines(), 1):
            original = raw.strip()
            if not original:
                continue
            stripped = strip_inline_comment(original).strip()
            if not stripped or stripped.startswith(("#", ";", "//", "!")):
                continue
            if stripped.startswith("-") and len(stripped) > 1 and stripped[1].isspace():
                stripped = stripped[2:].strip()
            if stripped.lower() in {"rules:", "payload:", "rule:", "rules", "payload"}:
                continue
            # Hosts format: 0.0.0.0 example.com or 127.0.0.1 localhost
            host_match = re.match(r"^(?:0\.0\.0\.0|127\.0\.0\.1|::1)\s+(.+)$", stripped, re.I)
            if host_match:
                hosts = [x.strip() for x in host_match.group(1).split()]
                for host in hosts:
                    if is_domain(host) and host.lower() not in {"localhost", "broadcasthost"}:
                        host_category = classify_rule_category(source, category, host)
                        self._add_rule("DOMAIN", host, host_category, source, line_number, original,
                                       None, inherited_policy, (), None)
                continue
            # AdGuard domain rules. Exception entries are placed in a separate high-priority allow category.
            adguard_exception = stripped.startswith("@@||") and stripped.endswith("^")
            if stripped.startswith("||") and stripped.endswith("^") or adguard_exception:
                domain = stripped[4:-1] if adguard_exception else stripped[2:-1]
                domain = domain.split("^")[0].strip().lower()
                if is_domain(domain):
                    cat = CAT_ALLOW if adguard_exception else classify_rule_category(source, category, domain)
                    self._add_rule("DOMAIN-SUFFIX", domain, cat, source, line_number, original,
                                   "DIRECT" if adguard_exception else None, inherited_policy,
                                   (), "domainset")
                else:
                    self._unconverted(source, line_number, original, "Invalid AdGuard domain rule.")
                continue
            # Plain domain/IP lists, including the domain-only DOMAIN-SET lists published by Sukka.
            if "," not in stripped and not stripped.startswith(("[", "<")):
                token = stripped.strip().strip('"').strip("'")
                if token.startswith("+."):
                    token = token[2:]
                if token.startswith("*."):
                    token = token[2:]
                ip_type, ip_value = is_ip_or_network(token)
                if ip_type:
                    cat = classify_rule_category(source, category, token)
                    self._add_rule(ip_type, ip_value or token, cat, source, line_number, original,
                                   None, inherited_policy, ("no-resolve",), None)
                    continue
                if is_domain(token):
                    cat = classify_rule_category(source, category, token)
                    self._add_rule("DOMAIN-SUFFIX", token.lower().rstrip("."), cat, source, line_number,
                                   original, None, inherited_policy, (), "domainset")
                    continue
            fields = split_rule_fields(stripped)
            if not fields:
                continue
            raw_type = fields[0].strip().upper()
            rule_type = RULE_TYPE_ALIASES.get(raw_type, raw_type)
            if rule_type in {"DOMAIN-SET", "RULE-SET"}:
                if len(fields) < 2 or not fields[1].startswith(("http://", "https://")):
                    self._unconverted(source, line_number, original, f"{raw_type} needs a downloadable URL; named/local rule-set references are not expanded.")
                    continue
                source_policy = None
                options: list[str] = []
                if len(fields) >= 3:
                    if fields[2].lower() in OPTION_WORDS:
                        options = fields[2:]
                    else:
                        source_policy = fields[2]
                        options = fields[3:]
                selected_policy = self.policy_for(category, source_policy, inherited_policy)
                remote_category = classify_rule_category(fields[1], category, fields[1])
                self._fetch_expansion(fields[1], source, line_number, remote_category,
                                      selected_policy, "domainset" if rule_type == "DOMAIN-SET" else "ruleset",
                                      depth, stack)
                continue
            if rule_type in {"FINAL", "MATCH"}:
                self._unconverted(source, line_number, original, "Terminal FINAL/MATCH rules are omitted from rule-set files to avoid shadowing later rules.")
                continue
            if rule_type not in SUPPORTED_RULE_TYPES:
                # Record lines that look like rules, but ignore ordinary YAML/config keys.
                if re.match(r"^[A-Za-z][A-Za-z0-9_-]*\s*,", stripped):
                    self._unconverted(source, line_number, original, f"Unrecognized rule type: {raw_type}")
                continue
            if len(fields) < 2:
                self._unconverted(source, line_number, original, "Rule has no match value.")
                continue
            value = fields[1].strip()
            if not value:
                self._unconverted(source, line_number, original, "Rule has an empty match value.")
                continue
            source_policy = None
            options = []
            if len(fields) >= 3:
                if fields[2].lower() in OPTION_WORDS:
                    options = fields[2:]
                else:
                    source_policy = fields[2]
                    options = fields[3:]
            cat = classify_rule_category(source, category, value)
            if rule_type == "GEOIP":
                value = value.upper()
            elif rule_type in {"DOMAIN", "DOMAIN-SUFFIX", "DOMAIN-KEYWORD", "DOMAIN-WILDCARD"}:
                value = normalize_rule_value(value)
                if rule_type in {"DOMAIN", "DOMAIN-SUFFIX"}:
                    value = value.lower().rstrip(".")
            self._add_rule(rule_type, value, cat, source, line_number, original,
                           source_policy, inherited_policy, options, None)



def parse_document_until_success(processor, content: str, source: str, default_category: str,
                                logger=None, progress=None) -> None:
    """Retry exceptional parser failures and roll back partial mutations before retrying."""
    def parse_once():
        rules_len = len(processor.rules)
        unconverted_len = len(processor.unconverted)
        sequence_before = processor.sequence
        expansion_seen_before = set(processor.expansion_seen)
        try:
            processor.parse_document(content, source, default_category=default_category)
        except Exception:
            del processor.rules[rules_len:]
            del processor.unconverted[unconverted_len:]
            processor.sequence = sequence_before
            processor.expansion_seen = expansion_seen_before
            raise

    retry_until_success(parse_once, f"parse rule file {source}", logger, progress)


def sort_and_deduplicate(rules: list[Rule]) -> tuple[list[Rule], int, list[dict]]:
    family_rank = {name: i for i, name in enumerate(FAMILY_ORDER)}
    ordered = sorted(rules, key=lambda r: (family_rank.get(r.family, 99), category_priority(r.category), r.sequence))
    exact_seen: set[tuple] = set()
    match_seen: dict[tuple, Rule] = {}
    final: list[Rule] = []
    duplicate_count = 0
    conflicts: list[dict] = []
    for rule in ordered:
        exact = rule.exact_key()
        if exact in exact_seen:
            duplicate_count += 1
            continue
        exact_seen.add(exact)
        match_key = rule.match_key()
        previous = match_seen.get(match_key)
        if previous is not None and previous.policy.lower() != rule.policy.lower():
            conflicts.append({
                "match": rule.render().rsplit(",", 1)[0],
                "kept_rule": previous.render(),
                "kept_category": previous.category,
                "kept_source": previous.source,
                "discarded_rule": rule.render(),
                "discarded_category": rule.category,
                "discarded_source": rule.source,
                "resolution": "Kept the rule earlier in the configured family/category priority order.",
            })
            duplicate_count += 1
            continue
        if previous is not None:
            duplicate_count += 1
            continue
        match_seen[match_key] = rule
        final.append(rule)
    final.sort(key=lambda r: (family_rank.get(r.family, 99), category_priority(r.category), r.sequence))
    return final, duplicate_count, conflicts


def output_text_for_rules(rules: list[Rule], header: Optional[list[str]] = None) -> str:
    lines = list(header or [])
    if lines:
        lines.append("")
    last_family = None
    last_category = None
    family_rank = {name: i for i, name in enumerate(FAMILY_ORDER)}
    ordered = sorted(rules, key=lambda r: (family_rank.get(r.family, 99), category_priority(r.category), r.sequence))
    for rule in ordered:
        if rule.family != last_family:
            if lines:
                lines.append("")
            lines.append(f"# ===== {FAMILY_LABELS.get(rule.family, rule.family)} =====")
            last_family = rule.family
            last_category = None
        if rule.category != last_category:
            lines.append(f"# --- {rule.category} ---")
            last_category = rule.category
        lines.append(rule.render_rule_set())
    return "\n".join(lines).rstrip() + "\n"


def rule_order_text(categories: list[str], generated_at: str, policy_map: dict[str, str]) -> str:
    """List generated by_category .lsr files and their configured Loon policy, without listing inner rules."""
    category_set = set(categories)
    ordered_categories = [category for category in CATEGORY_ORDER if category in category_set]
    # Keep any unexpected category files visible after the configured category priority.
    ordered_categories.extend(sorted(category_set - set(ordered_categories), key=str.casefold))
    effective_policy_map = dict(DEFAULT_POLICY_MAP)
    effective_policy_map.update(policy_map or {})
    lines = [
        "# Loon Rule-Set File Order",
        f"# Generated at: {generated_at}",
        "# Scope: generated rule-set files in by_category/ only.",
        "# Each entry lists the .lsr file, category, and policy to use in Loon [Remote Rule].",
        "# Rules inside the files are not listed or reordered here.",
        "# Order follows the generator's configured category priority; Loon uses the order in your actual configuration.",
        "",
    ]
    for index, category in enumerate(ordered_categories, start=1):
        policy = normalize_policy(effective_policy_map.get(category, effective_policy_map.get(CAT_MISC, "PROXY"))) or "PROXY"
        lines.append(f"[{index:04d}] by_category/{safe_filename(category)}.lsr | CATEGORY={category} | POLICY={policy}")
    return "\n".join(lines).rstrip() + "\n"


def export_results(output_dir: Path, rules: list[Rule], duplicate_count: int, conflicts: list[dict],
                   unconverted: list[dict], sources: list[dict], policy_map: dict[str, str],
                   force_policy: bool) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    by_category_dir = output_dir / "by_category"
    by_family_dir = output_dir / "by_family"
    by_category_dir.mkdir(exist_ok=True)
    by_family_dir.mkdir(exist_ok=True)
    generated_at = datetime.now().astimezone().isoformat(timespec="seconds")
    common_header = [
        f"# Generated by {APP_NAME} {VERSION}",
        f"# Generated at: {generated_at}",
        "# Rule source content is fetched at runtime; check each upstream repository license and attribution.",
    ]
    (output_dir / "all_rules.lsr").write_text(output_text_for_rules(rules, common_header), encoding="utf-8")
    for category in CATEGORY_ORDER:
        category_rules = [r for r in rules if r.category == category]
        if not category_rules:
            continue
        file_path = by_category_dir / (safe_filename(category) + ".lsr")
        file_path.write_text(output_text_for_rules(category_rules, common_header + [f"# Category: {category}"]), encoding="utf-8")

    generated_categories = [category for category in CATEGORY_ORDER if any(rule.category == category for rule in rules)]
    (output_dir / "rule_order.txt").write_text(rule_order_text(generated_categories, generated_at, policy_map), encoding="utf-8")

    for family in FAMILY_ORDER:
        family_rules = [r for r in rules if r.family == family]
        (by_family_dir / f"{family}.lsr").write_text(
            output_text_for_rules(family_rules, common_header + [f"# Family: {FAMILY_LABELS[family]}"]), encoding="utf-8")

    source_rows_path = output_dir / "rule_sources.csv"
    with source_rows_path.open("w", newline="", encoding="utf-8-sig") as handle:
        source_fields = ["rule", "category", "family", "source", "source_line", "original"]
        writer = csv.DictWriter(handle, fieldnames=source_fields)
        writer.writeheader()
        for rule in rules:
            writer.writerow({
                "rule": rule.render(), "category": rule.category, "family": rule.family,
                "source": rule.source, "source_line": rule.source_line, "original": rule.original,
            })

    conflict_path = output_dir / "conflicts.csv"
    conflict_fields = ["match", "kept_rule", "kept_category", "kept_source", "discarded_rule", "discarded_category", "discarded_source", "resolution"]
    with conflict_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=conflict_fields)
        writer.writeheader()
        writer.writerows(conflicts)

    with (output_dir / "unconverted.txt").open("w", encoding="utf-8") as handle:
        handle.write("# Rules or lines not emitted to Loon output\n")
        for item in unconverted:
            handle.write(f"\n[{item.get('source', '')}:{item.get('line', '')}] {item.get('reason', '')}\n")
            handle.write(item.get("text", "") + "\n")

    categories = {}
    families = {}
    for rule in rules:
        categories[rule.category] = categories.get(rule.category, 0) + 1
        families[rule.family] = families.get(rule.family, 0) + 1
    index_lines = ["# Loon rule output index", "", f"Generated: {generated_at}", "",
                   "`rule_order.txt` lists generated `by_category/*.lsr` files in category priority order and includes each file's `POLICY=` value for Loon `[Remote Rule]` entries.",
                   "It does not list or reorder the individual rules inside each category file.",
                   "A category/policy mapping can change the routing strategy; review it before importing into Loon.", "",
                   "## Category files", ""]
    for category in CATEGORY_ORDER:
        count = categories.get(category, 0)
        if count:
            index_lines.append(f"- `by_category/{safe_filename(category)}.lsr` - {category}: {count} rules; POLICY={normalize_policy(policy_map.get(category, DEFAULT_POLICY_MAP.get(category, "PROXY"))) or "PROXY"}")
    index_lines += ["", "## Family counts", ""]
    for family in FAMILY_ORDER:
        index_lines.append(f"- `{family}.lsr`: {families.get(family, 0)} rules")
    index_lines += ["", "## Files", "", "- `all_rules.lsr`: all rules in family/category order.",
                    "- `rule_order.txt`: numbered order of `by_category/*.lsr` files with `CATEGORY=` and `POLICY=`; it does not list or reorder rules inside those files.",
                    "- `by_category/`: one `.lsr` rule set per semantic category.",
                    "- `by_family/`: domainset/non_ip/ip split as `.lsr` rule sets.",
                    "- `rule_sources.csv`: source file and line for every kept rule.",
                    "- `conflicts.csv`: same match with competing policies; first rule in priority order wins.",
                    "- `unconverted.txt`: unsupported lines and skipped terminal rules.",
                    "- `manifest.json`: counts, settings and source inventory.", ""]
    (output_dir / "category_index.md").write_text("\n".join(index_lines), encoding="utf-8")

    manifest = {
        "app": APP_NAME,
        "version": VERSION,
        "generated_at": generated_at,
        "rule_count": len(rules),
        "duplicate_or_conflict_count": duplicate_count,
        "conflict_count": len(conflicts),
        "unconverted_count": len(unconverted),
        "category_counts": categories,
        "family_counts": families,
        "category_policy_map": policy_map,
        "force_policy_by_category": force_policy,
        "source_inventory": sources,
        "rule_order_file": "rule_order.txt",
        "rule_order_scope": "by_category .lsr rule-set files only; individual rules inside each file are not listed or reordered by rule_order.txt",
        "rule_order_category_files": [f"by_category/{safe_filename(category)}.lsr" for category in CATEGORY_ORDER if categories.get(category, 0)],
        "rule_sort_order": {
            "all_rules_lsr_family": FAMILY_ORDER,
            "all_rules_lsr_category": CATEGORY_ORDER,
            "all_rules_lsr_within_family_and_category": "original collection sequence",
        },
        "notes": [
            "SukkaW/Surge grouping style is used as a structural reference: domainset -> non_ip -> ip.",
            "Loon official rule syntax is the target format; DOMAIN-SET and URL RULE-SET references are expanded when downloadable.",
            "Generated rules are not a complete Loon profile and do not define policy groups or a FINAL rule.",
            "Respect the license and attribution of each upstream rule source.",
        ],
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    zip_path = output_dir / f"Loon_Rules_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for file_path in output_dir.rglob("*"):
            if file_path.is_file() and file_path != zip_path and not file_path.name.startswith("Loon_Rules_"):
                archive.write(file_path, file_path.relative_to(output_dir))
    return {
        "output_dir": str(output_dir), "zip_path": str(zip_path), "rule_count": len(rules),
        "duplicate_count": duplicate_count, "conflict_count": len(conflicts),
        "unconverted_count": len(unconverted), "category_counts": categories, "family_counts": families,
    }


def _repository_cache_dir(cache_root: str | Path, repository: str) -> Path:
    """Use a branch-specific cache directory for explicitly pinned repositories."""
    try:
        owner, repo, explicit_branch = parse_repo_spec(repository)
        branch = explicit_branch or REPOSITORY_BRANCHES.get((owner.casefold(), repo.casefold()))
        cache_identity = f"{owner}/{repo}@{branch}" if branch else f"{owner}/{repo}"
    except (TypeError, ValueError):
        cache_identity = repository.strip()
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", cache_identity).strip("._") or "repository"
    return Path(cache_root) / slug


def load_repository_cache(cache_root: str | Path, repository: str) -> Optional[dict]:
    """Return a complete cache manifest only when every referenced file exists."""
    if not str(cache_root or "").strip():
        return None
    manifest_path = _repository_cache_dir(cache_root, repository) / "manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not manifest.get("complete") or str(manifest.get("repository", "")).casefold() != repository.casefold():
            return None
        try:
            owner, repo, explicit_branch = parse_repo_spec(repository)
            expected_branch = explicit_branch or REPOSITORY_BRANCHES.get((owner.casefold(), repo.casefold()))
        except (TypeError, ValueError):
            expected_branch = None
        if expected_branch and manifest.get("branch") != expected_branch:
            return None
        files = manifest.get("files")
        if not isinstance(files, list) or not files:
            return None
        root = manifest_path.parent
        for item in files:
            if not isinstance(item, dict) or not item.get("cache_file") or not item.get("path") or not item.get("url"):
                return None
            target = (root / str(item["cache_file"])).resolve()
            if root.resolve() not in target.parents or not target.is_file():
                return None
        return manifest
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def iter_cached_repository_files(cache_root: str | Path, repository: str) -> Iterable[tuple[str, str, str]]:
    manifest = load_repository_cache(cache_root, repository)
    if not manifest:
        raise FileNotFoundError(f"No complete predownload cache for {repository}")
    root = _repository_cache_dir(cache_root, repository)
    for item in manifest["files"]:
        content = (root / item["cache_file"]).read_text(encoding="utf-8-sig", errors="replace")
        if not content.strip():
            raise ValueError(f"Cached rule file is empty: {repository}/{item['path']}")
        yield str(item["url"]), str(item["path"]), content


def run_prefetch(config: dict, logger=None, progress=None, repository_event=None) -> dict:
    """Download the fixed repositories to a local disk cache before rule generation."""
    cache_root = str(config.get("cacheDir") or config.get("cache_dir") or "").strip()
    if not cache_root:
        raise ValueError("A cache directory is required for repository pre-download")
    Path(cache_root).mkdir(parents=True, exist_ok=True)
    downloader = Downloader(logger=logger)
    crawler = GitHubCrawler(downloader, logger=logger, progress=None)
    results = []

    def report(repository: str, status: str, **details) -> None:
        payload = {"repository": repository, "status": status, **details}
        if repository_event:
            repository_event(payload)

    for repo in DEFAULT_REPOSITORIES:
        repo_dir = _repository_cache_dir(cache_root, repo)
        files_dir = repo_dir / "files"
        staging_dir = repo_dir / "files.pending"
        repo_dir.mkdir(parents=True, exist_ok=True)
        # Keep the last known-good cache available until the new snapshot is complete.
        shutil.rmtree(staging_dir, ignore_errors=True)
        staging_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = repo_dir / "manifest.json"

        downloaded = 0
        total = None
        current_file = ""
        report(repo, "downloading", downloaded=0, total=None, current_file="", message="正在获取仓库目录…")
        if logger:
            logger(f"[INFO] Starting repository pre-download: {repo}")
        if progress:
            progress(f"正在预下载仓库：{repo}")

        def on_repo_progress(message: str) -> None:
            nonlocal total, current_file
            if progress:
                progress(message)
            match = re.match(r"^(.+?): downloading (\d+)/(\d+) - (.+?)(?: \(([\d,]+) bytes\))?$", str(message), re.I)
            if match and match.group(1).casefold() == repo.casefold():
                total = int(match.group(3))
                current_file = match.group(4)
                report(repo, "downloading", downloaded=downloaded, total=total, current_file=current_file,
                       message=f"正在下载 {downloaded + 1}/{total}：{current_file}")
            elif str(message).startswith("正在重试："):
                report(repo, "retrying", downloaded=downloaded, total=total, current_file=current_file, message=str(message))

        crawler.progress = on_repo_progress
        manifest_files = []
        try:
            for url, relative_path, content in crawler.collect_repo_files(repo):
                normalized = str(relative_path).replace("\\", "/").lstrip("/")
                if not normalized or any(part == ".." for part in normalized.split("/")):
                    raise ValueError(f"Unsafe repository path: {relative_path}")
                digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
                cache_file = f"files/{digest}.txt"
                target = staging_dir / Path(cache_file).name
                temp_target = target.with_suffix(target.suffix + ".tmp")
                temp_target.write_text(content, encoding="utf-8", newline="")
                os.replace(temp_target, target)
                manifest_files.append({
                    "path": normalized,
                    "url": url,
                    "cache_file": cache_file,
                    "bytes": len(content.encode("utf-8")),
                })
                downloaded += 1
                current_file = ""
                report(repo, "downloading", downloaded=downloaded, total=total, current_file="",
                       message=f"已下载 {downloaded}/{total or '?'} 个文件")

            manifest = {
                "version": 1,
                "repository": repo,
                "branch": REPOSITORY_BRANCHES.get(tuple(part.casefold() for part in repo.split("/", 1))) if "/" in repo else None,
                "complete": True,
                "completed_at": datetime.now().astimezone().isoformat(),
                "files": manifest_files,
            }
            backup_dir = repo_dir / "files.previous"
            shutil.rmtree(backup_dir, ignore_errors=True)
            moved_old_files = False
            installed_new_files = False
            try:
                if files_dir.exists():
                    os.replace(files_dir, backup_dir)
                    moved_old_files = True
                os.replace(staging_dir, files_dir)
                installed_new_files = True
                temp_manifest = manifest_path.with_suffix(".json.tmp")
                temp_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
                os.replace(temp_manifest, manifest_path)
            except Exception:
                if installed_new_files:
                    shutil.rmtree(files_dir, ignore_errors=True)
                if moved_old_files and backup_dir.exists():
                    os.replace(backup_dir, files_dir)
                raise
            shutil.rmtree(backup_dir, ignore_errors=True)
            report(repo, "completed", downloaded=downloaded, total=downloaded, current_file="",
                   message=f"预下载完成，共 {downloaded} 个文件")
            if logger:
                logger(f"[DONE] Pre-downloaded {repo}: {downloaded} files")
            results.append({"repository": repo, "status": "completed", "files": downloaded})
        except Exception as exc:
            shutil.rmtree(staging_dir, ignore_errors=True)
            report(repo, "failed", downloaded=downloaded, total=total, current_file=current_file,
                   message=f"预下载失败：{exc}")
            if logger:
                logger(f"[ERROR] Repository pre-download failed for {repo}: {exc}")
            results.append({"repository": repo, "status": "failed", "files": downloaded, "error": str(exc)})

    return {"cache_dir": cache_root, "repositories": results,
            "completed": sum(1 for item in results if item["status"] == "completed"),
            "total": len(DEFAULT_REPOSITORIES)}

def run_generation(config: dict, logger=None, progress=None) -> dict:
    """Run the shared rule pipeline for Tkinter or Electron frontends."""
    def emit_log(message: str) -> None:
        log_call(logger, message)

    def emit_progress(message: str) -> None:
        log_call(progress, message)

    # Source policy is intentionally fixed: only these three repositories are crawled.
    # Complete startup pre-download caches are reused; missing caches fall back to live
    # fetching. Ignore legacy/custom repository lists, direct URLs and discovery settings.
    requested_repos = config.get("repositories", config.get("repos", [])) or []
    requested_urls = config.get("directUrls", config.get("urls", [])) or []
    requested_query = str(config.get("query", "") or "").strip()
    if requested_repos or requested_urls or requested_query or config.get("onlineDiscovery") or config.get("online_discovery"):
        emit_log("[INFO] Fixed source allowlist is active; custom repositories, direct URLs, and repository discovery are ignored.")

    repos = list(DEFAULT_REPOSITORIES)
    output_dir = Path(str(config.get("outputDir") or config.get("output_dir") or (Path.home() / "Documents" / "LoonRuleGeneratorOutput"))).expanduser()
    # Category-to-policy routing is fixed in code; ignore any legacy or external overrides.
    policy_map = dict(DEFAULT_POLICY_MAP)
    force_policy = True
    cache_root = str(config.get("cacheDir") or config.get("cache_dir") or "").strip()

    downloader = Downloader(logger=emit_log)
    crawler = GitHubCrawler(downloader, logger=emit_log, progress=emit_progress)
    dedup_repos = list(DEFAULT_REPOSITORIES)
    sources = [{
        "type": "fixed_repository_allowlist",
        "status": "ok",
        "repositories": list(DEFAULT_REPOSITORIES),
        "count": len(DEFAULT_REPOSITORIES),
        "fetch_mode": "predownload_cache_or_live_fallback",
    }]
    emit_log(f"[INFO] Using {len(dedup_repos)} fixed GitHub repositories; completed pre-download caches will be reused.")
    emit_progress(f"Preparing to crawl {len(dedup_repos)} fixed repositories")

    processor = RuleProcessor(downloader, policy_map, force_policy=force_policy, logger=emit_log)
    for repo_index, repo_spec in enumerate(dedup_repos, 1):
        emit_log(f"[INFO] Crawling repository: {repo_spec}")
        emit_progress(f"Repository {repo_index}/{len(dedup_repos)}: {repo_spec}")
        file_count = 0
        fetch_mode = "live"
        try:
            cached_manifest = load_repository_cache(cache_root, repo_spec) if cache_root else None
            if cached_manifest:
                fetch_mode = "predownload_cache"
                emit_log(f"[INFO] Using predownloaded cache for {repo_spec}: {len(cached_manifest['files'])} files")
                repository_files = iter_cached_repository_files(cache_root, repo_spec)
            else:
                emit_log(f"[INFO] No complete predownload cache for {repo_spec}; fetching live.")
                repository_files = crawler.collect_repo_files(repo_spec)
            for url, path, content in repository_files:
                file_count += 1
                emit_log(f"[PARSE] {repo_spec}/{path}")
                parse_document_until_success(
                    processor,
                    content,
                    url,
                    default_category=classify_category(path, repo_spec),
                    logger=emit_log,
                    progress=emit_progress,
                )
                sources.append({"repository": repo_spec, "path": path, "url": url, "status": "parsed", "bytes": len(content.encode("utf-8"))})
            sources.append({"repository": repo_spec, "status": "ok", "files": file_count, "fetch_mode": fetch_mode})
        except Exception as exc:
            emit_log(f"[WARN] Repository crawl failed for {repo_spec}: {exc}")
            sources.append({"repository": repo_spec, "status": "failed", "error": str(exc), "files": file_count})

    emit_log(f"[INFO] Parsed candidate rules: {len(processor.rules)}")
    rules, duplicate_count, conflicts = sort_and_deduplicate(processor.rules)
    emit_log(f"[INFO] Unique output rules: {len(rules)}; duplicates/conflicts removed: {duplicate_count}; policy conflicts: {len(conflicts)}")
    emit_progress("Exporting classified Loon rule files")
    result = export_results(output_dir, rules, duplicate_count, conflicts, processor.unconverted, sources, policy_map, force_policy)
    emit_log(f"[DONE] Exported to: {result['output_dir']}")
    emit_log(f"[DONE] ZIP bundle: {result['zip_path']}")
    emit_log(f"[DONE] Rules={result['rule_count']}, conflicts={result['conflict_count']}, unconverted={result['unconverted_count']}")
    return result


def run_json_worker() -> int:
    """JSON-lines IPC mode used by the Electron main process."""
    def emit(event_type: str, **payload) -> None:
        print(json.dumps({"type": event_type, **payload}, ensure_ascii=False), flush=True)

    try:
        raw = sys.stdin.read()
        config = json.loads(raw or "{}")
        logger = lambda message: emit("log", message=str(message))
        progress = lambda message: emit("status", message=str(message))
        if str(config.get("action", "")).lower() == "prefetch":
            result = run_prefetch(
                config,
                logger=logger,
                progress=progress,
                repository_event=lambda payload: emit("repository", **payload),
            )
            emit("prefetch-done", result=result)
            return 0
        result = run_generation(config, logger=logger, progress=progress)
        emit("done", result=result)
        return 0
    except Exception as exc:
        emit("error", message=str(exc))
        return 1


# ------------------------------- Tkinter GUI -------------------------------
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception:  # pragma: no cover - only relevant on Python builds without Tk
    tk = None


class LoonRuleGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} {VERSION}")
        self.root.geometry("1120x820")
        self.root.minsize(940, 700)
        self.events: queue.Queue = queue.Queue()
        self.worker_thread: Optional[threading.Thread] = None
        self.output_dir_var = tk.StringVar(value=str(Path(__file__).resolve().parent / "output"))
        self.status_var = tk.StringVar(value="\u5c31\u7eea\uff1a\u4ed3\u5e93\u9884\u4e0b\u8f7d\u5b8c\u6210\u540e\uff0c\u70b9\u51fb\u5f00\u59cb\u751f\u6210\u3002")
        self._build_ui()
        self.root.after(120, self._poll_events)

    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"))
        style.configure("Hint.TLabel", foreground="#5d6670")
        outer = ttk.Frame(self.root, padding=14)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Loon \u89c4\u5219\u914d\u7f6e\u5de5\u5177", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="GitHub \u6293\u53d6  |  \u8bed\u6cd5\u8f6c\u6362  |  \u5206\u7c7b  |  \u53bb\u91cd  |  \u51b2\u7a81\u68c0\u67e5  |  \u672c\u5730\u5bfc\u51fa", style="Hint.TLabel").pack(anchor="w", pady=(2, 10))

        self.notebook = ttk.Notebook(outer)
        self.notebook.pack(fill="both", expand=True)
        source_tab = ttk.Frame(self.notebook, padding=12)
        log_tab = ttk.Frame(self.notebook, padding=12)
        self.notebook.add(source_tab, text="\u6765\u6e90\u8bbe\u7f6e")
        self.notebook.add(log_tab, text="\u65e5\u5fd7\u4e0e\u7ed3\u679c")

        ttk.Label(source_tab, text="\u56fa\u5b9a\u5728\u7ebf\u89c4\u5219\u4ed3\u5e93\uff08\u8fd0\u884c\u65f6\u4ece GitHub \u5b9e\u65f6\u62c9\u53d6\uff09").pack(anchor="w")
        repo_frame = ttk.Frame(source_tab)
        repo_frame.pack(fill="both", expand=True, pady=(4, 8))
        self.repo_text = tk.Text(repo_frame, height=8, wrap="none", state="disabled")
        self.repo_text.pack(side="left", fill="both", expand=True)
        self.repo_text.configure(state="normal")
        self.repo_text.insert("1.0", "\n".join(DEFAULT_REPOSITORIES) + "\n\nblackmatrix7/ios_rule_script: rule/Loon/ only")
        self.repo_text.configure(state="disabled")
        ttk.Label(source_tab, text="\u53ea\u4f7f\u7528\u4ee5\u4e0a 3 \u4e2a\u4ed3\u5e93\uff1b\u4e0d\u4f1a\u641c\u7d22\u6216\u52a0\u5165\u5176\u4ed6\u4ed3\u5e93\uff0c\u4e5f\u4e0d\u63a5\u53d7\u81ea\u5b9a\u4e49\u89c4\u5219 URL\u3002", style="Hint.TLabel").pack(anchor="w", pady=(0, 8))

        settings = ttk.Frame(source_tab)
        settings.pack(fill="x", pady=(0, 2))
        ttk.Label(settings, text="\u89c4\u5219\u6587\u4ef6\u4e0d\u9650\u6570\u91cf\uff0c\u4e0d\u9650\u5355\u4e2a\u6587\u4ef6\u5927\u5c0f\uff08\u4ec5\u4e0b\u8f7d\u8bc6\u522b\u4e3a\u89c4\u5219\u7684\u6587\u4ef6\uff09", style="Hint.TLabel").pack(side="left", padx=(0, 16))

        out_frame = ttk.LabelFrame(source_tab, text="\u8f93\u51fa\u76ee\u5f55", padding=8)
        out_frame.pack(fill="x", pady=(12, 0))
        ttk.Entry(out_frame, textvariable=self.output_dir_var).pack(side="left", fill="x", expand=True)
        ttk.Button(out_frame, text="\u9009\u62e9...", command=self._choose_output).pack(side="left", padx=(8, 0))

        ttk.Label(log_tab, textvariable=self.status_var, wraplength=1000).pack(anchor="w", pady=(0, 8))
        log_frame = ttk.Frame(log_tab)
        log_frame.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_frame, wrap="word", state="disabled", font=("Consolas", 9))
        log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        log_scroll.pack(side="right", fill="y")

        bottom = ttk.Frame(outer)
        bottom.pack(fill="x", pady=(12, 0))
        self.start_button = ttk.Button(bottom, text="\u5f00\u59cb\u6293\u53d6\u3001\u8f6c\u6362\u3001\u53bb\u91cd\u5e76\u5bfc\u51fa", command=self._start)
        self.start_button.pack(side="left")
        ttk.Button(bottom, text="\u6e05\u7a7a\u65e5\u5fd7", command=self._clear_log).pack(side="left", padx=(8, 0))
        ttk.Button(bottom, text="\u6253\u5f00\u8f93\u51fa\u76ee\u5f55", command=self._open_output).pack(side="left", padx=(8, 0))
        ttk.Label(bottom, text="\u672c\u5730\u8fd0\u884c\uff0c\u4e0d\u4f1a\u4e0a\u4f20\u4f60\u7684\u672c\u5730\u89c4\u5219\u6587\u4ef6\u3002", style="Hint.TLabel").pack(side="right")

    def _choose_output(self):
        folder = filedialog.askdirectory(initialdir=self.output_dir_var.get() or str(Path.home()))
        if folder:
            self.output_dir_var.set(folder)

    def _append_log(self, message: str):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _open_output(self):
        path = Path(self.output_dir_var.get()).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            else:
                messagebox.showinfo(APP_NAME, str(path))
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def _start(self):
        if self.worker_thread and self.worker_thread.is_alive():
            return
        try:
            output_dir = Path(self.output_dir_var.get()).expanduser()
        except Exception:
            messagebox.showerror(APP_NAME, "Invalid output directory.")
            return
        self.start_button.configure(state="disabled")
        self.status_var.set("\u6b63\u5728\u6293\u53d6\u548c\u5904\u7406\u89c4\u5219\uff0c\u8bf7\u4e0d\u8981\u5173\u95ed\u7a97\u53e3\u3002")
        self.notebook.select(1)
        self._append_log("\n=== New run started ===")
        self.worker_thread = threading.Thread(target=self._worker, args=(output_dir,), daemon=True)
        self.worker_thread.start()

    def _worker(self, output_dir):
        def logger(message):
            self.events.put(("log", message))
        def progress(message):
            self.events.put(("status", message))
        config = {"outputDir": str(output_dir)}
        try:
            result = run_generation(config, logger=logger, progress=progress)
            self.events.put(("done", result))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _poll_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "log":
                    self._append_log(payload)
                elif kind == "status":
                    self.status_var.set(payload)
                elif kind == "done":
                    self.start_button.configure(state="normal")
                    self.status_var.set(
                        f"\u751f\u6210\u5b8c\u6210\uff1a{payload['rule_count']} \u6761\u89c4\u5219\uff0c\u53bb\u9664 {payload['duplicate_count']} \u4e2a\u91cd\u590d/\u51b2\u7a81\uff0c{payload['conflict_count']} \u4e2a\u7b56\u7565\u51b2\u7a81\uff0c{payload['unconverted_count']} \u6761\u672a\u8f6c\u6362\u3002")
                    self._append_log("\n--- Summary ---")
                    self._append_log(json.dumps(payload, ensure_ascii=False, indent=2))
                    messagebox.showinfo(APP_NAME, f"\u89c4\u5219\u751f\u6210\u5b8c\u6210\uff01\n\n\u89c4\u5219\u6570\uff1a{payload['rule_count']}\n\u7b56\u7565\u51b2\u7a81\uff1a{payload['conflict_count']}\n\u672a\u8f6c\u6362\uff1a{payload['unconverted_count']}\n\nZIP\uff1a{payload['zip_path']}")
                elif kind == "error":
                    self.start_button.configure(state="normal")
                    self.status_var.set("\u751f\u6210\u5931\u8d25\uff0c\u8bf7\u67e5\u770b\u65e5\u5fd7\u3002")
                    self._append_log("[ERROR] " + payload)
                    messagebox.showerror(APP_NAME, payload)
        except queue.Empty:
            pass
        self.root.after(120, self._poll_events)


def main():
    if tk is None:
        raise SystemExit("Tkinter is not available in this Python installation.")
    root = tk.Tk()
    LoonRuleGeneratorApp(root)
    root.mainloop()


if __name__ == "__main__":
    if "--json-worker" in sys.argv:
        raise SystemExit(run_json_worker())
    main()
