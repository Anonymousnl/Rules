@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 goto use_py
where python >nul 2>nul
if %errorlevel%==0 goto use_python
echo Python 3.10+ was not found. Install Python first.
pause
exit /b 1
:use_py
py -3 -m pip install --upgrade pyinstaller
if errorlevel 1 goto failed
py -3 -m PyInstaller --noconfirm --clean --onefile --console --name LoonRuleEngine --distpath engine\dist --workpath engine\build --paths . engine\engine_entry.py
if errorlevel 1 goto failed
goto success
:use_python
python -m pip install --upgrade pyinstaller
if errorlevel 1 goto failed
python -m PyInstaller --noconfirm --clean --onefile --console --name LoonRuleEngine --distpath engine\dist --workpath engine\build --paths . engine\engine_entry.py
if errorlevel 1 goto failed
goto success
:success
echo.
echo Engine build complete: engine\dist\LoonRuleEngine.exe
exit /b 0
:failed
echo.
echo Engine build failed. Check Python and pip installation.
pause
exit /b 1
