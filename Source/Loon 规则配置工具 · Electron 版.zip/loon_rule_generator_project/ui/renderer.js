const $ = (id) => document.getElementById(id);
let lastOutputDir = '';
let logCount = 0;
let isRunning = false;
let isPrefetching = false;
let removeRunListener = null;
let removePrefetchListener = null;

function splitLines(value) {
  return String(value || '').split(/\r?\n/).map((line) => line.trim()).filter((line) => line && !line.startsWith('#'));
}

const FIXED_REPOSITORIES = [
  'SukkaLab/ruleset.skk.moe',
  'blackmatrix7/ios_rule_script',
  'Loyalsoldier/clash-rules'
];

function collectSettings() {
  return { outputDir: $('output-dir').value.trim() };
}

function collectRunConfig() {
  return {
    repositories: [...FIXED_REPOSITORIES],
    directUrls: [],
    query: '',
    onlineDiscovery: false,
    discoveryCount: 0,
    maxRepositories: FIXED_REPOSITORIES.length,
    outputDir: $('output-dir').value.trim()
  };
}

function applySettings(settings, defaults) {
  const value = { ...defaults, ...settings };
  $('output-dir').value = value.outputDir || defaults.outputDir || '';
  lastOutputDir = $('output-dir').value;
}

function setStatus(state, title, message, pill) {
  const pillLabels = { READY: '就绪', RUNNING: '运行中', COMPLETED: '已完成', FAILED: '失败', STOPPED: '已停止' };
  $('run-status-title').textContent = title;
  $('run-status-message').textContent = message;
  $('run-state-pill').textContent = pillLabels[pill] || pillLabels[state.toUpperCase()] || '就绪';
  $('run-status-icon').classList.toggle('running', state === 'running');
  $('run-status-icon').classList.toggle('failed', state === 'failed');
  $('run-status-icon').classList.toggle('success', state === 'success');
  $('progress-track').classList.toggle('running', state === 'running');
  if (state !== 'running') $('progress-bar').style.width = state === 'success' ? '100%' : '0%';
}

function setRunning(running) {
  isRunning = running;
  updateTaskButtons();
  $('output-dir').disabled = running;
  $('browse-output-button').disabled = running;
}

function updateTaskButtons() {
  $('start-button').disabled = isRunning || isPrefetching;
  $('stop-button').classList.toggle('hidden', !(isRunning || isPrefetching));
  $('stop-button').textContent = isRunning ? '停止任务' : '停止预下载';
  $('refresh-prefetch-button').disabled = isRunning || isPrefetching;
}

function setPrefetching(active) {
  isPrefetching = active;
  updateTaskButtons();
}

function appendLog(message, kind = 'info') {
  const view = $('log-view');
  const empty = $('log-empty');
  if (empty) empty.remove();
  const row = document.createElement('div');
  row.className = `log-line ${kind}`;
  const time = document.createElement('span');
  time.className = 'log-time';
  time.textContent = new Date().toLocaleTimeString([], { hour12: false });
  const content = document.createElement('span');
  content.className = 'log-message';
  content.textContent = message;
  row.append(time, content);
  view.appendChild(row);
  view.scrollTop = view.scrollHeight;
  logCount += 1;
  $('log-count').textContent = `${logCount} 条`;
}

function classifyLog(message) {
  if (/\[ERROR\]|\[FAIL\]/i.test(message)) return 'error';
  if (/\[WARN\]/i.test(message)) return 'warn';
  if (/\[DONE\]/i.test(message)) return 'done';
  if (/\[PARSE\]/i.test(message)) return 'parse';
  return 'info';
}

function localizeProgressMessage(message) {
  const text = String(message || '');
  let match;
  if ((match = text.match(/^Preparing to crawl (\d+) fixed repositories$/i))) {
    return `准备抓取 ${match[1]} 个固定仓库`;
  }
  if ((match = text.match(/^Repository (\d+)\/(\d+): (.+)$/i))) {
    return `正在处理仓库 ${match[1]}/${match[2]}：${match[3]}`;
  }
  if ((match = text.match(/^(.+?): downloading (\d+)\/(\d+) - (.+?)(?: \(([\d,]+) bytes\))?$/i))) {
    const size = match[5] ? `（${match[5]} 字节）` : '';
    return `正在下载规则文件：${match[1]}（${match[2]}/${match[3]}）· ${match[4]}${size}`;
  }
  if (/^Exporting classified Loon rule files$/i.test(text)) {
    return '正在导出分类后的 Loon 规则文件';
  }
  return text;
}

function localizeErrorMessage(message) {
  const text = String(message || '未知错误');
  const known = new Map([
    ['A generation task is already running.', '已有生成任务正在运行。'],
    ['Not a github.com repository URL', '这不是有效的 GitHub 仓库地址。'],
    ['Repository URL must include owner/repo', '仓库地址必须包含所有者和仓库名称。'],
    ['Invalid repository spec', '仓库配置无效。'],
    ['Only http/https URLs are supported', '仅支持 HTTP 或 HTTPS 地址。'],
    ['The read operation timed out', '读取超时，请检查网络后重试。'],
  ]);
  if (known.has(text)) return known.get(text);
  const translateReason = (reason) => {
    const reasons = {
      'not found': '未找到',
      'rate limit exceeded': '已超出 API 请求限额',
      'forbidden': '禁止访问',
      'unauthorized': '未授权',
      'bad request': '请求格式无效',
      'bad gateway': '网关错误',
      'internal server error': '服务器内部错误',
      'service unavailable': '服务暂不可用',
      'too many requests': '请求过于频繁'
    };
    return reasons[String(reason || '').toLowerCase()] || reason;
  };
  let match;
  if ((match = text.match(/^HTTP Error 403: (.*)$/i))) {
    const reason = translateReason(match[1]);
    return `GitHub 请求被拒绝或触发访问限额（HTTP 403）${reason ? `：${reason}` : ''}`;
  }
  if ((match = text.match(/^HTTP Error 404: (.*)$/i))) {
    const reason = translateReason(match[1]);
    return `请求的资源不存在（HTTP 404）${reason ? `：${reason}` : ''}`;
  }
  if ((match = text.match(/^HTTP Error (\d+): (.*)$/i))) {
    const reason = translateReason(match[2]);
    return `网络请求失败（HTTP ${match[1]}）${reason ? `：${reason}` : ''}`;
  }
  if (/getaddrinfo failed/i.test(text)) return '无法解析服务器地址，请检查网络或 DNS 设置。';
  if (/certificate verify failed/i.test(text)) return 'HTTPS 证书验证失败，请检查系统证书或网络代理。';
  if (/connection refused/i.test(text)) return '网络连接被拒绝，请检查网络设置。';
  if (/connection reset/i.test(text)) return '网络连接被重置，请稍后重试。';
  if (/timed out/i.test(text)) return '网络请求超时，请检查网络后重试。';
  if (/urlopen error/i.test(text)) return '网络连接失败，请检查网络、代理或 DNS 设置。';
  return text;
}

function localizeLogMessage(message) {
  const text = String(message || '');
  let match;
  if (text === '[INFO] Fixed source allowlist is active; custom repositories, direct URLs, and repository discovery are ignored.') {
    return '[信息] 已启用固定仓库白名单；自定义仓库、直接 URL 和仓库自动发现均已禁用。';
  }
  if ((match = text.match(/^\[INFO\] Using (\d+) fixed GitHub repositories; rule files will be fetched live\.$/))) {
    return `[信息] 使用 ${match[1]} 个固定 GitHub 仓库；规则文件将在运行时在线获取。`;
  }
  if ((match = text.match(/^\[INFO\] Crawling repository: (.+)$/))) {
    return `[信息] 正在抓取仓库：${match[1]}`;
  }
  if ((match = text.match(/^\[INFO\] (.+): restricting crawl to (.+)$/))) {
    return `[信息] ${match[1]}：抓取范围限定为 ${match[2]}`;
  }
  if ((match = text.match(/^\[INFO\] (.+): found (\d+) candidate rule files; no per-repository file-count or per-file size cap\.$/))) {
    return `[信息] ${match[1]}：发现 ${Number(match[2]).toLocaleString()} 个候选规则文件；未设置单仓库文件数量或单文件大小上限。`;
  }
  if ((match = text.match(/^\[WARN\] (.+): recursive GitHub tree response was truncated; walking directory trees individually\.$/))) {
    return `[警告] ${match[1]}：GitHub 返回的目录树不完整，正在逐个遍历子目录。`;
  }
  if ((match = text.match(/^\[WARN\] (.+): one directory tree is still truncated by GitHub; the API omitted entries from (.+)\.$/))) {
    return `[警告] ${match[1]}：GitHub 返回的目录树仍不完整，API 可能遗漏了目录 ${match[2]} 中的项目。`;
  }
  if ((match = text.match(/^\[WARN\] Failed to download (.+?): (.+)$/))) {
    return `[警告] 下载失败：${match[1]}；原因：${localizeErrorMessage(match[2])}`;
  }
  if ((match = text.match(/^\[WARN\] Repository crawl failed for (.+?): (.+)$/))) {
    return `[警告] 仓库抓取失败：${match[1]}；原因：${localizeErrorMessage(match[2])}`;
  }
  if ((match = text.match(/^\[INFO\] Parsed candidate rules: (\d+)$/))) {
    return `[信息] 解析到的候选规则：${Number(match[1]).toLocaleString()} 条`;
  }
  if ((match = text.match(/^\[INFO\] Unique output rules: (\d+); duplicates\/conflicts removed: (\d+); policy conflicts: (\d+)$/))) {
    return `[信息] 去重后规则：${Number(match[1]).toLocaleString()} 条；移除重复/冲突项：${Number(match[2]).toLocaleString()} 条；策略冲突：${Number(match[3]).toLocaleString()} 条`;
  }
  if ((match = text.match(/^\[DONE\] Exported to: (.+)$/))) {
    return `[完成] 已导出到：${match[1]}`;
  }
  if ((match = text.match(/^\[DONE\] ZIP bundle: (.+)$/))) {
    return `[完成] ZIP 压缩包：${match[1]}`;
  }
  if ((match = text.match(/^\[INFO\] Starting repository pre-download: (.+)$/))) {
    return `[信息] 正在预下载仓库：${match[1]}`;
  }
  if ((match = text.match(/^\[DONE\] Pre-downloaded (.+?): (\d+) files$/))) {
    return `[完成] 仓库预下载完成：${match[1]}，共 ${Number(match[2]).toLocaleString()} 个文件`;
  }
  if ((match = text.match(/^\[RETRY\] (.+?) failed on attempt (\d+): (.+)\. Retrying in ([\d.]+)s; no retry limit\.$/))) {
    return `[重试] ${match[1]} 第 ${match[2]} 次失败：${localizeErrorMessage(match[3])}；${match[4]} 秒后再次尝试（不限制重试次数）`;
  }
  if ((match = text.match(/^\[DONE\] Rules=(\d+), conflicts=(\d+), unconverted=(\d+)$/))) {
    return `[完成] 规则：${Number(match[1]).toLocaleString()} 条；策略冲突：${Number(match[2]).toLocaleString()} 条；未转换：${Number(match[3]).toLocaleString()} 条`;
  }
  if ((match = text.match(/^\[PARSE\]\s*(.+)$/))) return `[解析] ${match[1]}`;
  if ((match = text.match(/^\[ENGINE\]\s*(.+)$/))) return `[引擎] ${localizeErrorMessage(match[1])}`;
  if ((match = text.match(/^\[INFO\]\s*(.*)$/))) return `[信息] ${match[1]}`;
  if ((match = text.match(/^\[WARN\]\s*(.*)$/))) return `[警告] ${localizeErrorMessage(match[1])}`;
  if ((match = text.match(/^\[ERROR\]\s*(.*)$/))) return `[错误] ${localizeErrorMessage(match[1])}`;
  if ((match = text.match(/^\[FAIL\]\s*(.*)$/))) return `[失败] ${localizeErrorMessage(match[1])}`;
  return localizeErrorMessage(text);
}

function resetStats() {
  $('stat-rules').textContent = '—';
  $('stat-duplicates').textContent = '—';
  $('stat-conflicts').textContent = '—';
  $('stat-unconverted').textContent = '—';
}

function showResult(result) {
  $('stat-rules').textContent = Number(result.rule_count || 0).toLocaleString();
  $('stat-duplicates').textContent = Number(result.duplicate_count || 0).toLocaleString();
  $('stat-conflicts').textContent = Number(result.conflict_count || 0).toLocaleString();
  $('stat-unconverted').textContent = Number(result.unconverted_count || 0).toLocaleString();
  $('result-summary').textContent = `${Number(result.rule_count || 0).toLocaleString()} 条规则 · ${Number(result.conflict_count || 0).toLocaleString()} 个策略冲突`;
  $('result-zip').textContent = result.zip_path || '已导出，但未返回 ZIP 路径';
  $('open-result-button').disabled = false;
  lastOutputDir = result.output_dir || $('output-dir').value;
}

async function saveCurrentSettings() {
  try {
    await window.loonAPI.saveSettings(collectSettings());
  } catch (error) {
    appendLog(`保存设置失败：${error.message || error}`, 'warn');
  }
}

async function startRun() {
  if (isRunning || isPrefetching) return;
  const config = collectRunConfig();
  if (!config.outputDir) {
    appendLog('请先选择导出目录。', 'warn');
    $('output-dir').focus();
    return;
  }
  await saveCurrentSettings();
  resetStats();
  $('result-summary').textContent = '正在生成…';
  $('result-zip').textContent = '等待导出结果…';
  $('open-result-button').disabled = true;
  setRunning(true);
  setStatus('running', '正在处理规则', '正在启动后台引擎并访问 GitHub。', 'RUNNING');
  appendLog('=== 新任务开始 ===', 'info');
  window.loonAPI.startGeneration(config);
}

function handleRunEvent(event) {
  if (!event || !event.type) return;
  if (event.type === 'log') {
    const message = String(event.message || '');
    appendLog(localizeLogMessage(message), classifyLog(message));
  } else if (event.type === 'status') {
    $('run-status-message').textContent = localizeProgressMessage(event.message || '正在处理…');
  } else if (event.type === 'done') {
    const result = event.result || {};
    setRunning(false);
    setStatus('success', '生成完成', `已导出 ${Number(result.rule_count || 0).toLocaleString()} 条规则。`, 'COMPLETED');
    showResult(result);
    appendLog(`完成：${result.rule_count || 0} 条规则，${result.conflict_count || 0} 个策略冲突，${result.unconverted_count || 0} 条未转换。`, 'done');
      saveCurrentSettings();
  } else if (event.type === 'error') {
    setRunning(false);
    const errorMessage = localizeErrorMessage(event.message || '未知错误');
    setStatus('failed', '任务失败', errorMessage, 'FAILED');
    appendLog(`[错误] ${errorMessage}`, 'error');
    } else if (event.type === 'stopped') {
    setRunning(false);
    setStatus('failed', '任务已停止', String(event.message || '任务已停止。'), 'STOPPED');
    appendLog(event.message || '任务已停止。', 'warn');
    }
}

function updateRepositoryStatus(event) {
  const repo = String(event.repository || '');
  const badge = document.querySelector(`[data-repo-status="${CSS.escape(repo)}"]`);
  if (!badge) return;
  const state = String(event.status || 'waiting');
  const downloaded = Number(event.downloaded || 0);
  const total = Number(event.total || 0);
  let label = '等待预下载';
  if (state === 'downloading') {
    label = total > 0 ? `预下载 ${Math.min(downloaded + (event.current_file ? 1 : 0), total)}/${total}` : '正在获取目录';
  } else if (state === 'retrying') {
    label = `重试中 · ${downloaded} 个`;
  } else if (state === 'completed') {
    label = `已完成 · ${downloaded} 个文件`;
  } else if (state === 'failed') {
    label = `失败 · ${downloaded} 个文件`;
  } else if (state === 'stopped') {
    label = '已暂停';
  }
  badge.dataset.state = state;
  badge.textContent = label;
  badge.title = String(event.message || label);
  const completed = document.querySelectorAll('.repo-status-badge[data-state="completed"]').length;
  const summary = $('prefetch-summary');
  if (summary) summary.textContent = `仓库预下载进度：${completed}/${FIXED_REPOSITORIES.length} 个完成。${event.message || ''}`;
}

function handlePrefetchEvent(event) {
  if (!event || !event.type) return;
  if (event.type === 'repository') {
    updateRepositoryStatus(event);
  } else if (event.type === 'status') {
    $('prefetch-summary').textContent = localizeProgressMessage(event.message || '正在预下载仓库…');
    if (isPrefetching) setStatus('running', '正在预下载仓库', localizeProgressMessage(event.message || '正在下载仓库文件…'), 'RUNNING');
  } else if (event.type === 'log') {
    const message = String(event.message || '');
    appendLog(localizeLogMessage(message), classifyLog(message));
  } else if (event.type === 'prefetch-done') {
    setPrefetching(false);
    const result = event.result || {};
    const completed = Number(result.completed || 0);
    const total = Number(result.total || FIXED_REPOSITORIES.length);
    const message = `仓库预下载完成：${completed}/${total} 个成功。生成时优先使用最新完整缓存；预下载失败的仓库保留上次完整缓存，没有可用缓存时才在线抓取。`;
    $('prefetch-summary').textContent = message;
    setStatus(completed === total ? 'success' : 'ready', completed === total ? '仓库预下载完成' : '预下载部分完成', message, 'READY');
    appendLog(message, completed === total ? 'done' : 'warn');
  } else if (event.type === 'error') {
    setPrefetching(false);
    const message = localizeErrorMessage(event.message || '预下载失败');
    $('prefetch-summary').textContent = `预下载未完成：${message}。可以重试；生成时会使用上次完整缓存，没有可用缓存时才在线获取。`;
    setStatus('failed', '预下载未完成', message, 'FAILED');
    appendLog(`[错误] ${message}`, 'error');
    document.querySelectorAll('.repo-status-badge[data-state="downloading"], .repo-status-badge[data-state="retrying"]').forEach((badge) => {
      badge.dataset.state = 'failed';
      badge.textContent = '未完成';
    });
  } else if (event.type === 'stopped') {
    setPrefetching(false);
    const message = String(event.message || '预下载已停止。');
    $('prefetch-summary').textContent = `${message} 可重新预下载，或直接开始生成。`;
    document.querySelectorAll('.repo-status-badge[data-state="downloading"], .repo-status-badge[data-state="retrying"], .repo-status-badge[data-state="waiting"]').forEach((badge) => {
      badge.dataset.state = 'stopped';
      badge.textContent = '已暂停';
    });
    setStatus('ready', '预下载已暂停', message, 'READY');
    appendLog(message, 'warn');
  }
}

function beginPrefetch() {
  setPrefetching(true);
  document.querySelectorAll('.repo-status-badge').forEach((badge) => {
    badge.dataset.state = 'waiting';
    badge.textContent = '等待预下载';
    badge.title = '';
  });
  $('prefetch-summary').textContent = `正在启动预下载：${FIXED_REPOSITORIES.length} 个固定仓库。大型仓库可能需要较长时间。`;
  setStatus('running', '正在预下载仓库', '正在逐个下载仓库目录和规则文件。', 'RUNNING');
  appendLog('=== 开始预下载固定仓库 ===', 'info');
  window.loonAPI.startPrefetch();
}

async function restartPrefetch() {
  if (isRunning || isPrefetching) return;
  await window.loonAPI.stopPrefetch();
  beginPrefetch();
}

async function browseOutput() {
  const selected = await window.loonAPI.selectOutputDir($('output-dir').value);
  if (selected) {
    $('output-dir').value = selected;
    lastOutputDir = selected;
    await saveCurrentSettings();
  }
}

async function openOutput(useLastResult = false) {
  const target = (useLastResult && lastOutputDir) ? lastOutputDir : $('output-dir').value;
  try {
    await window.loonAPI.openOutputDir(target);
  } catch (error) {
    appendLog(`无法打开输出目录：${error.message || error}`, 'error');
  }
}

function clearLog() {
  $('log-view').replaceChildren();
  const empty = document.createElement('div');
  empty.className = 'log-empty';
  empty.id = 'log-empty';
  empty.innerHTML = '<div class="empty-symbol">⌁</div><strong>日志已清空</strong><span>后续任务日志会继续显示在这里。</span>';
  $('log-view').appendChild(empty);
  logCount = 0;
  $('log-count').textContent = '0 条';
}

window.addEventListener('DOMContentLoaded', async () => {
  try {
    const data = await window.loonAPI.getInitialData();
    $('version-label').textContent = `v${data.version}`;
    applySettings(data.settings, data.defaults);
  } catch (error) {
    appendLog(`加载设置失败：${error.message || error}`, 'error');
  }

  $('start-button').addEventListener('click', startRun);
  $('stop-button').addEventListener('click', () => {
    if (isRunning) window.loonAPI.stopGeneration();
    else if (isPrefetching) window.loonAPI.stopPrefetch();
  });
  $('refresh-prefetch-button').addEventListener('click', restartPrefetch);
  $('browse-output-button').addEventListener('click', browseOutput);
  $('open-output-button').addEventListener('click', () => openOutput(false));
  $('open-result-button').addEventListener('click', () => openOutput(true));
  $('clear-log-button').addEventListener('click', clearLog);
  for (const id of ['output-dir']) {
    $(id).addEventListener('change', saveCurrentSettings);
  }
  removeRunListener = window.loonAPI.onRunEvent(handleRunEvent);
  removePrefetchListener = window.loonAPI.onPrefetchEvent(handlePrefetchEvent);
  beginPrefetch();
});

window.addEventListener('beforeunload', () => {
  if (removeRunListener) removeRunListener();
  if (removePrefetchListener) removePrefetchListener();
});
